
import flatbuffers
from abc import ABC, abstractmethod
from queue import Queue
import zmq

from pythonclient.utils import event_monitoring
from pythonclient.config_read import ConfigObjectClass
import pythonclient.schema.guiServer as guiServer
from pythonclient.zmqBase import ZMQBase

class GUIServerClient(ABC, ZMQBase):
    """
    A client class for communicating with a GUI server, handling strategy state updates, and managing GUI-related data.

    This class includes methods for initializing connections with the GUI server, handling login and logout processes,
    updating strategy states and parameters, and processing incoming GUI messages.

    Attributes
    ----------
    gui_config : ConfigObjectClass
        Configuration object containing GUI server settings.
    SYMBOL_ID_DICT : dict
        Dictionary mapping symbol IDs to GUI row IDs.
    STRATEGY_STATE_DICT : dict
        Dictionary mapping GUI row IDs to strategy states.
    SEND_QUEUE : Queue
        Queue for sending messages to the GUI server.
    gui_server_dealer_socket : zmq.Socket
        Dealer socket for communication with the GUI server.
    gui_server_monitor_socket : zmq.Socket
        Monitor socket for observing the dealer socket's events.

    Methods
    -------
    __init__(self, config_path: str)
        Initializes the GUIServerClient instance.
    guiserver_init(self)
        Initializes and sets up the connection with the GUI server.
    init_symbols(self, trading_symbols)
        Initializes trading symbols for GUI representation.
    gui_login(self)
        Sends a login request to the GUI server and handles the response.
    gui_logout(self)
        Logs out from the GUI server and closes the connection.
    update_state(self, row_indx, state)
        Sends a state update request for a specific strategy row.
    on_state_update(self, row_index, state, strategy_id, client_id, error_code, error_reason)
        Abstract method to be implemented for handling state updates.
    on_parameter_update(self, row_index, column, value)
        Abstract method to be implemented for handling parameter updates.
    __process_gui_message(self, message)
        Processes incoming messages from the GUI server.
    get_state(self, row_indx)
        Retrieves the state of a strategy at a given row index.
    get_state_symbol(self, symbol)
        Retrieves the state of a strategy associated with a given symbol.
    handle_gui_data(self)
        Handles incoming GUI data and processes messages.
    update_gui_parameter(self, indx, column, value, dtype, configurable)
        Sends a request to update a GUI parameter and updates local state.
    """
    
    def __init__(self, config_path: str):
        """
        Initializes the GUIServerClient instance.

        Sets up the configuration from the provided path, initializes GUI server communication sockets,
        and prepares dictionaries for strategy state management.

        Parameters
        ----------
        config_path : str
            Path to the configuration file used for setting up the GUI server connection.
        """

        super().__init__()
        
        self.gui_config: ConfigObjectClass = ConfigObjectClass(config_path)
        self.guiserver_init()
        
        self.SYMBOL_ID_DICT = {}  # key: symbol_id, value: gui_row_id 
        self.STRATEGY_STATE_DICT = {}  # key: gui_row_id, value: state
        
        self.__strategy_state_map = {y:x for x,y in guiServer.StrategyState.__dict__.items() if not x.startswith('__')}
        self.__status_map = {y:x for x,y in guiServer.Status.__dict__.items() if not x.startswith('__')}
        self.__error_code_map = {y:x for x,y in guiServer.ErrorCodes.__dict__.items() if not x.startswith('__')}

        ##
        self.SEND_QUEUE: Queue = Queue()
    
    
    def guiserver_init(self):
        """
        Initializes the connection with the GUI server.

        Sets up the dealer and monitor sockets for communication with the GUI server, registers callbacks,
        and logs in to the GUI server.
        """
        
        ##
        identity = str(self.gui_config.strategy_id).encode('utf-8')

        ##
        self.gui_config.masterlog.info('Connecting to GUI Server')
        
        self.gui_server_dealer_socket = self.ZMQ_CONTEXT.socket(zmq.DEALER)
        self.gui_server_dealer_socket.setsockopt(zmq.IDENTITY, identity)
        self.gui_server_dealer_socket.setsockopt(zmq.HEARTBEAT_IVL, int(self.gui_config.hearbeat_interval*1000))
        self.gui_server_dealer_socket.setsockopt(zmq.HEARTBEAT_TIMEOUT, int(self.gui_config.heartbeat_timeout*1000))
        self.gui_server_dealer_socket.RCVTIMEO = int(self.gui_config.connection_timeout * 1000)
        self.gui_server_dealer_socket.connect(self.gui_config.gui_server_router)
        
        ##
        self.gui_server_monitor_socket = self.gui_server_dealer_socket.get_monitor_socket()
        
        self.ZMQ_CALLBACK_DICT[self.gui_server_monitor_socket] = event_monitoring
        self.ZMQ_CALLBACK_DICT[self.gui_server_dealer_socket] = self.handle_gui_data
        
        ##
        self.ALL_SOCKET_LIST.append(self.gui_server_dealer_socket)
        self.ALL_SOCKET_LIST.append(self.gui_server_monitor_socket)
        
        self.SOCKET_INFO_DICT[self.gui_server_dealer_socket.underlying] = {'name': 'gui_server_dealer_socket', "type": "gui_server"}
        self.SOCKET_INFO_DICT[self.gui_server_monitor_socket.underlying] = {'name': 'gui_server_monitor_socket', "type": "monitor"}
        
        self.gui_login()

    def init_symbols(self, trading_symbols):
        """
        Initializes trading symbols for GUI representation.

        Maps trading symbols to GUI row IDs and initializes their state in the strategy state dictionary.

        Parameters
        ----------
        trading_symbols : list
            List of trading symbols to be initialized.

        Raises
        ------
        Exception
            If a duplicate symbol ID is encountered in the trading_symbols list.
        """
        colname = self.gui_config.symbol_colname
        for i, sym_ in enumerate(trading_symbols):
            symbol = str(sym_)
            if symbol in self.SYMBOL_ID_DICT:
                raise Exception("Duplicate Symbol ID")
            
            self.SYMBOL_ID_DICT[symbol] = i
            self.STRATEGY_STATE_DICT[i] = False
            
            self.gui_config.masterlog.debug(f"{i}, {colname}, {symbol}, str, {False}")
            self.update_gui_parameter(i, colname, str(symbol), "str", False)
    
    def gui_login(self):
        """
        Sends a login request to the GUI server and processes the response.

        Constructs and sends a login request using FlatBuffers, waits for the server's reply, and handles the login status.
        On failure, raises an exception with the error code.
        """
        
        builder = flatbuffers.Builder(2048)

        guiServer.LogInRequestMessageStart(builder)
        guiServer.LogInRequestMessageAddClientId(builder, self.gui_config.client_id)
        guiServer.LogInRequestMessageAddStrategyId(builder, self.gui_config.strategy_id)
        loginMsg = guiServer.LogInRequestMessageEnd(builder)
        
        ##
        guiServer.ClientMessageStart(builder)
        guiServer.AddClientUnionType(builder, guiServer.ClientUnion.LogInRequestMessage)
        guiServer.AddClientUnion(builder, loginMsg)
        requestMsg = guiServer.ClientMessageEnd(builder)

        ##
        guiServer.MessageStart(builder)
        guiServer.AddMessageUnionType(builder, guiServer.MessageUnion.ClientMessage)
        guiServer.AddMessageUnion(builder, requestMsg)
        message = guiServer.MessageEnd(builder)

        builder.Finish(message)
        buf = builder.Output()
        
        self.gui_config.masterlog.info('Sending GUI Server Log In Request')
        self.gui_server_dealer_socket.send(buf)
        
        ##
        binBuffer = self.gui_server_dealer_socket.recv()
        
        self.gui_config.masterlog.info('Received GUI Server Log In Reply')
        
        m = guiServer.Message.GetRootAs(binBuffer, 0)       
                
        GUIMessage = guiServer.GUIMessage()
        GUIMessage.Init(m.MessageUnion().Bytes, m.MessageUnion().Pos)
        
        loginReply = guiServer.LogInResponseMessage()
        loginReply.Init(GUIMessage.GuiUnion().Bytes, GUIMessage.GuiUnion().Pos)

        status = loginReply.LogInStatus()
        if status == guiServer.Status.FAILURE:
            self.gui_config.masterlog.error('GUI Server Log In Failed')
            error_code = loginReply.ErrorCode()
            raise Exception('GUI Server Log In Failed with Error Code: {}'.format(error_code))
        
        elif status == guiServer.Status.SUCCESS:
            self.gui_config.masterlog.info('GUI Server Log In Successful')
            self.gui_config.masterlog.info('GUI Server Client ID: {}'.format(self.gui_config.client_id))
    
    
    def gui_logout(self):
        
        self.gui_server_dealer_socket.close()
        
        # ##
        # builder = flatbuffers.Builder(2048)

        # guiServer.LogOutRequestMessageStart(builder)
        # guiServer.LogOutRequestMessageAddClientId(builder, self.gui_config.client_id)
        # guiServer.LogOutRequestMessageAddStrategyId(builder, self.gui_config.strategy_id)
        # logoutMsg = guiServer.LogOutRequestMessageEnd(builder)
        
        # ##
        # guiServer.ClientMessageStart(builder)
        # guiServer.AddClientUnionType(builder, guiServer.ClientUnion.LogOutRequestMessage)
        # guiServer.AddClientUnion(builder, logoutMsg)
        # requestMsg = guiServer.ClientMessageEnd(builder)

        # ##
        # guiServer.MessageStart(builder)
        # guiServer.AddMessageUnionType(builder, guiServer.MessageUnion.ClientMessage)
        # guiServer.AddMessageUnion(builder, requestMsg)
        # message = guiServer.MessageEnd(builder)

        # builder.Finish(message)
        # buf = builder.Output()
        
        # self.gui_config.masterlog.info('Sending GUI Server Log Out Request')
        # self.gui_server_dealer_socket.send(buf)
        
        # ##
        # binBuffer = self.gui_server_dealer_socket.recv()
        
        # self.gui_config.masterlog.info('Received GUI Server Log Out Reply')
        
        # m = guiServer.Message.GetRootAs(binBuffer, 0)       
                
        # GUIMessage = guiServer.GUIMessage()
        # GUIMessage.Init(m.MessageUnion().Bytes, m.MessageUnion().Pos)
        
        # logOutReply = guiServer.LogOutResponseMessage()
        # logOutReply.Init(GUIMessage.GuiUnion().Bytes, GUIMessage.GuiUnion().Pos)

        # status = logOutReply.LogOutStatus()
        # if status == guiServer.Status.FAILURE:
        #     self.gui_config.masterlog.error('GUI Server Log Out Failed')
        
        # elif status == guiServer.Status.SUCCESS:
        #     self.gui_config.masterlog.info('GUI Server Log Out Successful')
        #     self.gui_server_dealer_socket.close()

    
    def update_state(self, row_indx, state):
        """
        Sends a request to update the state of a specific strategy row in the GUI.

        Constructs a state update request using FlatBuffers and adds it to the send queue.

        Parameters
        ----------
        row_indx : int
            The row index in the GUI corresponding to the strategy.
        state : str
            Desired state to set for the strategy, either 'START' or 'STOP'.

        Raises
        ------
        AssertionError
            If the provided state is neither 'START' nor 'STOP'.
        """
        
        assert state in ["START", "STOP"], "state can be either start or stop"
        
        builder = flatbuffers.Builder(2048)

        guiServer.StrategyStateUpdateRequestStart(builder)
        guiServer.StrategyStateUpdateRequestAddStrategyId(builder, self.gui_config.strategy_id)
        guiServer.StrategyStateUpdateRequestAddClientId(builder, self.gui_config.client_id)
        guiServer.StrategyStateUpdateRequestAddIndex(builder, row_indx)
        
        if state == "START":
            send_state = guiServer.StrategyState.START
        
        elif state == "STOP":
            send_state = guiServer.StrategyState.STOP
        
        guiServer.StrategyStateUpdateRequestAddState(builder, send_state)
        update_message = guiServer.StrategyStateUpdateRequestEnd(builder)
        
        guiServer.ClientMessageStart(builder)
        guiServer.ClientMessageAddClientUnionType(builder, guiServer.ClientUnion.StrategyStateUpdateRequest)
        guiServer.ClientMessageAddClientUnion(builder, update_message)
        requestMsg = guiServer.ClientMessageEnd(builder)
                
        guiServer.MessageStart(builder)
        guiServer.AddMessageUnionType(builder, guiServer.MessageUnion.ClientMessage)
        guiServer.AddMessageUnion(builder, requestMsg)
        message = guiServer.MessageEnd(builder)

        builder.Finish(message)
        buf = builder.Output()

        self.gui_config.masterlog.info('Sending GUI Server Update state request')
        self.SEND_QUEUE.put((self.gui_server_dealer_socket, buf))

    
    @abstractmethod
    def on_state_update(self, row_index, state, strategy_id, client_id, error_code, error_reason):
        """
        This method should be implemented by the user to define behavior for strategy state updates.
        
        This method is called when a strategy state update is received from the GUI server.

        Parameters
        ----------
        row_index : int
            The row index in the GUI where the state update occurred.
        state : str
            - 'START' if the strategy was started.
            - 'STOP' if the strategy was stopped.
        strategy_id : int
            The ID of the strategy that was updated.
        client_id : int
            The client ID associated with the update.
        error_code : int
            Error code received in response to the state update request.
        on_state_update : str
            Error reason received in response to the state update request.
        """
        pass
    
    
    @abstractmethod
    def on_parameter_update(self, parameter_ls):
        """
        Abstract method to handle parameter updates.

        This method should be implemented by the user to define behavior for strategy parameter updates.

        Parameters
        ----------
        parameter_ls : list
            List of tuples containing the row index, column name, and new value of the updated parameter.
            - row index : int
            - column name : str
            - new value : Any
        """
        pass
        
        
    def __process_gui_message(self, message):

        """
        Processes GUI messages based on their type.
        
        Parameters
        ----------
        message : Any
            GUI message to be processed.
        """
        
        ##
        GUIMessage = guiServer.GUIMessage()
        GUIMessage.Init(message.MessageUnion().Bytes, message.MessageUnion().Pos)
        guiUnionType = GUIMessage.GuiUnionType()
        
        ##
        if (guiUnionType == guiServer.GUIUnion.StrategyStateUpdateResponse) or (guiUnionType == guiServer.GUIUnion.StrategyStateUpdateRequest):
            
            stratStateUpdateResponse = guiServer.StrategyStateUpdateResponse()
            stratStateUpdateResponse.Init(GUIMessage.GuiUnion().Bytes, GUIMessage.GuiUnion().Pos)
            
            error_code = stratStateUpdateResponse.ErrorCode()
            client_id = stratStateUpdateResponse.ClientId()
            strategy_id = stratStateUpdateResponse.StrategyId()
            state = stratStateUpdateResponse.State()
            row_index = stratStateUpdateResponse.Index()
            
            ##
            state = self.__strategy_state_map[state] # START/STOP
            
            error_reason = None
            if error_code:
                error_reason = self.__error_code_map[error_code]
            
            self.on_state_update(row_index, state, strategy_id, client_id, error_code, error_reason)
            
            if error_code:
                self.gui_config.masterlog.error(f'Strategy State Update Failed: {self.__error_code_map[error_code]}')
                
            else:
                state_ = self.__strategy_state_map[stratStateUpdateResponse.State()]
                self.STRATEGY_STATE_DICT[stratStateUpdateResponse.Index()] = state_
        
        if guiUnionType == guiServer.GUIUnion.GUIStrategyParametersUpdateRequest:
            guiStratPramReq = guiServer.GUIStrategyParametersUpdateRequest()
            guiStratPramReq.Init(GUIMessage.GuiUnion().Bytes, GUIMessage.GuiUnion().Pos)
            
            ## Check if it requires an ack
            self.gui_config.masterlog.debug(f"requries ack: {guiStratPramReq.Ack()}")
            parameter_ls = []
            for i in range(guiStratPramReq.ParametersLength()):

                if guiStratPramReq.Parameters(i).ValueType() == guiServer.ParameterValueUnion.FloatValue:                    
                    floatValue = guiServer.FloatValue()
                    floatValue.Init(guiStratPramReq.Parameters(i).Value().Bytes, guiStratPramReq.Parameters(i).Value().Pos)
                    value = floatValue.Value()
                
                elif guiStratPramReq.Parameters(i).ValueType() == guiServer.ParameterValueUnion.IntValue:
                    intValue = guiServer.IntValue()
                    intValue.Init(guiStratPramReq.Parameters(i).Value().Bytes, guiStratPramReq.Parameters(i).Value().Pos)
                    value = intValue.Value()
                    
                elif guiStratPramReq.Parameters(i).ValueType() == guiServer.ParameterValueUnion.StringValue:
                    stringValue = guiServer.StringValue()
                    stringValue.Init(guiStratPramReq.Parameters(i).Value().Bytes, guiStratPramReq.Parameters(i).Value().Pos)
                    value = stringValue.Value()
                    
                
                row_indx = guiStratPramReq.Parameters(i).Index()
                column = guiStratPramReq.Parameters(i).Name()
                
                self.gui_config.masterlog.debug("GUI Strategy Parameters Update Request Received: {} {} {}".format(row_indx, column, value))
                
                if isinstance(column, bytes):
                    column = column.decode('utf-8')
                
                if isinstance(value, bytes):
                    value = value.decode('utf-8')
                
                parameter_ls.append((row_indx, column, value))

            if guiStratPramReq.Ack():
                builder = flatbuffers.Builder(0)
                
                guiServer.GUIStrategyParametersUpdateResponseStart(builder)
                guiServer.GUIStrategyParametersUpdateResponseAddClientId(builder, guiStratPramReq.ClientId())
                guiServer.GUIStrategyParametersUpdateResponseAddStrategyId(builder, guiStratPramReq.StrategyId())
                guiServer.GUIStrategyParametersUpdateResponseAddSuccess(builder, guiServer.Status.SUCCESS)
                GUIStrategyParametersUpdateResponse = guiServer.GUIStrategyParametersUpdateResponseEnd(builder)
                
                guiServer.ClientMessageStart(builder)
                guiServer.ClientMessageAddClientUnionType(builder, guiServer.ClientUnion.GUIStrategyParametersUpdateResponse)
                guiServer.ClientMessageAddClientUnion(builder, GUIStrategyParametersUpdateResponse)
                clnMessage = guiServer.ClientMessageEnd(builder)
                
                guiServer.MessageStart(builder)
                guiServer.MessageAddMessageUnionType(builder, guiServer.MessageUnion.ClientMessage)
                guiServer.MessageAddMessageUnion(builder, clnMessage)
                message = guiServer.MessageEnd(builder)
                
                builder.Finish(message)
                buf = builder.Output()
                
                self.SEND_QUEUE.put((self.gui_server_dealer_socket, buf))
            
            
            ##
            self.on_parameter_update(parameter_ls)


    ##
    def get_state(self, row_indx: int):
        """
        Get the state of the strategy at the specified row index.
        
        Parameters
        ----------
        row_indx : int
            Row index of the strategy whose state needs to be retrieved.
        
        Returns
        -------
        state : 'START' | 'STOP' | None
            State of the row with the specified row index. 'START' if the row is in the "START" state, 'STOP' otherwise.
        
        """
        return self.STRATEGY_STATE_DICT.get(row_indx, None)
    
    ##
    def get_state_symbol(self, symbol):
        """
        Gets the state of the specified symbol.
        
        Parameters
        ----------
        symbol : int | str
            Symbol of the strategy whose state needs to be retrieved.
        
        Returns
        -------
        state : 'START' | 'STOP'
            State of the strategy with the specified symbol. 'START' if the strategy is in the "START" state, 'STOP' otherwise.

        """
        
        ##
        row_indx = self.SYMBOL_ID_DICT.get(str(symbol), None)
        
        if row_indx is None:
            raise Exception("Symbol ID not found")
        
        return self.get_state(row_indx)
    
    def handle_gui_data(self):
        """
        Listens for and processes messages received from the GUI server.
        """
        msg = self.gui_server_dealer_socket.recv()

        #
        message = guiServer.Message.GetRootAs(msg, 0)
        messageUnion = message.MessageUnionType()

        if messageUnion == guiServer.MessageUnion.GUIMessage:
            self.__process_gui_message(message)
        
        else:
            self.gui_config.masterlog.error('Unknown Message Type Received')

        
    def update_gui_parameter(self, indx, column, value, dtype, configurable):
        """
        Updates a parameter in the GUI.

        Sends a parameter update request to the GUI server and optionally waits for an acknowledgment.

        Parameters
        ----------
        indx : int
            Row index of the parameter to be updated.
        column : str
            Column name of the strategy parameter to be updated.
        value : Any
            New value of the strategy parameter.
        dtype : str
            Data type of the value parameter (one of 'str', 'int', 'float').
        configurable : bool
            Indicates if the parameter is configurable from the GUI.

        Raises
        ------
        AssertionError
            If dtype is not one of 'str', 'int', 'float', or if configurable is not a boolean.
        """
        
        assert dtype in ["str", "int", "float"], "dtype can be either str, int or float"
        assert configurable in [True, False], "configurable can be either True or False"
        
        builder = flatbuffers.Builder(0)
        strategy_params = list()

        col_name = builder.CreateString(column)
        requires_ack = False
        
        if dtype == "str":                        
            union_type = guiServer.ParameterValueUnion.StringValue
            val_str = builder.CreateString(value)
            
            guiServer.StringValueStart(builder)
            guiServer.StringValueAddValue(builder, val_str)
            value = guiServer.StringValueEnd(builder)
        
        elif dtype == "int":
            union_type = guiServer.ParameterValueUnion.IntValue
            
            guiServer.IntValueStart(builder)
            guiServer.IntValueAddValue(builder, value)
            value = guiServer.IntValueEnd(builder)
        
        elif dtype == "float":
            union_type = guiServer.ParameterValueUnion.FloatValue
            
            guiServer.FloatValueStart(builder)
            guiServer.FloatValueAddValue(builder, value)
            value = guiServer.FloatValueEnd(builder)
        
        ##
        guiServer.StrategyParameterStart(builder)
        guiServer.StrategyParameterAddName(builder, col_name)
        guiServer.StrategyParameterAddIndex(builder, indx)
        guiServer.StrategyParameterAddValueType(builder, union_type)
        guiServer.StrategyParameterAddValue(builder, value)
        guiServer.StrategyParameterAddConfigurable(builder, configurable)
        strategy_params.append(guiServer.StrategyParameterEnd(builder))
                
        
        guiServer.UpdateStrategyParametersRequestStartParametersVector(builder, 1)
        for sp in reversed(strategy_params):
            builder.PrependUOffsetTRelative(sp)
        
        ##
        parameters = builder.EndVector(1)

        guiServer.UpdateStrategyParametersRequestStart(builder)
        guiServer.UpdateStrategyParametersRequestAddClientId(builder, self.gui_config.client_id)
        guiServer.UpdateStrategyParametersRequestAddStrategyId(builder, self.gui_config.strategy_id)
        guiServer.UpdateStrategyParametersRequestAddParameters(builder, parameters)
        guiServer.UpdateStrategyParametersRequestAddAck(builder, requires_ack)
        
        UpdateStrategyParametersRequest = guiServer.UpdateStrategyParametersRequestEnd(builder)
        
        guiServer.ClientMessageStart(builder)
        guiServer.ClientMessageAddClientUnionType(builder, guiServer.ClientUnion.UpdateStrategyParametersRequest)
        guiServer.ClientMessageAddClientUnion(builder, UpdateStrategyParametersRequest)
        clnMessage = guiServer.ClientMessageEnd(builder)
        
        guiServer.MessageStart(builder)
        guiServer.MessageAddMessageUnionType(builder, guiServer.MessageUnion.ClientMessage)
        guiServer.MessageAddMessageUnion(builder, clnMessage)
        message = guiServer.MessageEnd(builder)
        
        builder.Finish(message)
        buf = builder.Output()
        
        self.SEND_QUEUE.put((self.gui_server_dealer_socket, buf))
        # self.gui_server_dealer_socket.send(buf)

        
