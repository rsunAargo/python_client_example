
import json
import logging
import sys

def setup_logger(filename, logger_name="pair_logs", file_level=logging.DEBUG, stream_level=logging.INFO):

    logger = logging.getLogger(logger_name)
    logger.setLevel(logging.DEBUG)

    formatter = logging.Formatter("%(asctime)s,%(msecs)03d %(levelname)-8s [%(filename)s:%(lineno)d] %(message)s", datefmt="%Y-%m-%d %H:%M:%S")

    ## Settting File handler formatter to create log file
    file_handler = logging.FileHandler(filename, mode="w")
    file_handler.setLevel(file_level)
    file_handler.setFormatter(formatter)

    ## Settting Stream handler formatter to print logs
    stream_handler = logging.StreamHandler(sys.stdout) # sys.stdout
    stream_handler.setLevel(stream_level)
    stream_handler.setFormatter(formatter)

    ## Adding handler to logger
    logger.addHandler(file_handler)
    logger.addHandler(stream_handler)

    return logging.getLogger(logger_name)


TS_EXCHANG_MAPPING = {"CME": "OHIO", "ICE": "OHIO", "EURONEXT": "LONDON", "EUREX": "LONDON", "ICE_L": "LONDON", "NSE": "MUMBAI", "JPX": "OSAKA"}
MD_EXCHANG_MAPPING = {"CME": "OHIO", "ICE": "OHIO", "EURONEXT": "LONDON", "EUREX": "LONDON", "ICE_L": "LONDON", "NSE": "MUMBAI", "JPX": "OSAKA"}

class ConfigObjectClass:
    def __init__(self, file_path):
        with open(file_path, 'r') as f:
            config = json.load(f)
        
        self.db_config = config['DB_CONFIG']
        self.mode = config['MODE']
        
        assert config['MODE'] in ['PaperTrading', "Live"], "MODE should be either PaperTrading or Live"
        
        self.gui_server_router = config['BK_SERVER_ROUTER_LIVE'] if self.mode == "Live" else config['BK_SERVER_ROUTER_PAPER']
        self.strategy_id = config['STRATEGY_ID']
        self.client_id = config['CLIENT_ID']
        self.account_id_config = config['ACCOUNT_ID_CONFIG']
        
        self.region_ip_config = config['REGION_IP_CONFIG'] # region_ip_config
        
        all_region_set = set(["OHIO", "LONDON", "MUMBAI", "OSAKA", "PAPER"])
        
        assert set(self.region_ip_config.keys()).difference(all_region_set) == set(), "Region name not in OHIO, LONDON, MUMBAI, OSAKA, PAPER"
        
        ## REGION EXCHANGE MAPPING STATIC MAPPING
        if config['MODE'] == "PaperTrading":
            self.ts_exchange_region_mapping = {"CME": "PAPER", "ICE": "PAPER", "EURONEXT": "PAPER", "EUREX": "PAPER", "ICE_L": "PAPER", "NSE": "PAPER", "JPX": "PAPER"}
        
        elif config['MODE'] == "Live":
            self.ts_exchange_region_mapping = TS_EXCHANG_MAPPING
        
        #
        self.md_exchange_region_mapping = MD_EXCHANG_MAPPING

        # In seconds
        self.connection_timeout = config['CONNECTION_TIMEOUT']
        self.hearbeat_interval = config['HEARTBEAT_INTERVAL']
        self.heartbeat_timeout = config['HEARTBEAT_TIMEOUT']
        self.response_timeout = config['RESPONSE_TIMEOUT']
        self.symbol_colname = config['SYMBOL_COLNAME']
        self.logging_config = config['LOGGING_CONFIG']
        self.masterlog = setup_logger(self.logging_config['LOGGING_FILEPATH'], file_level=getattr(logging, self.logging_config['FILEHANDLER_LOGGING_LEVEL']), \
                                      stream_level=getattr(logging, self.logging_config['STREAMHANDLER_LOGGING_LEVEL']))

        self.socker_monitor_logger = setup_logger(self.logging_config['SOCKET_FILEPATH'], logger_name="socket_monitoring", file_level=getattr(logging, self.logging_config['FILEHANDLER_LOGGING_LEVEL']), \
                                        stream_level=getattr(logging, self.logging_config['STREAMHANDLER_LOGGING_LEVEL']))
        

        self.masterlog.info("Config Read Completed")

