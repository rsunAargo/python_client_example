
import flatbuffers
from abc import ABC, abstractmethod
import datetime as dt
from typing import TypedDict, Dict
from queue import Queue
import zmq
import copy

from pythonclient.config_read import ConfigObjectClass
import pythonclient.schema.marketDataServer as marketDataServer
from pythonclient.utils import event_monitoring
from pythonclient.zmqBase import ZMQBase


class InnerDict(TypedDict):
    timestamp: dt.datetime
    status: str
    response_status: str

class MarketDataServerClient(ABC, ZMQBase):
    """
    A client class for communicating with a market data server, handling market data updates, and managing market data-related operations.

    This class includes methods for initializing connections with the market data server, handling login and logout processes,
    processing various types of market data, and sending data requests to the market data server.

    Attributes
    ----------
    md_config : ConfigObjectClass
        Configuration object containing market data server settings.
    SEND_QUEUE : Queue
        Queue for sending messages to the market data server.
    SYMBOL_ID_MAPPING : dict
        Dictionary mapping symbol names to their respective IDs.
    SYMBOL_NAME_MAPPING : dict
        Dictionary mapping symbol IDs to their names.
    SYMBOL_EXCHANGE_MAPPING : dict
        Dictionary mapping symbol names to their respective exchanges.

    Methods
    -------
    __init__(self, config_path)
        Initializes the MarketDataServerClient instance.
    marketdata_server_init(self)
        Initializes and sets up the connection with the market data server.
    marketdata_logout(self, dealer_socket, sub_socket)
        Logs out from the market data server and closes the connections.
    on_trade_data(self, timestamp, symbol, price, size, open_interest)
        Abstract method to process trade data received from the market data server.
    on_ohlcv_data(self, start_ts, end_ts, symbol, open, high, low, close, volume, open_interest)
        Abstract method to process OHLCV data received from the market data server.
    on_bidask_data(self, symbol, status, timestamp, price, size, data_action, side, data_type, seq_num)
        Abstract method to process bid/ask data received from the market data server.
    on_instrument_status(self, timestamp, symbol, symbol_status, symbol_status_code, req_status)    
        Abstract method to process instrument status data received from the market data server.
    __process_bid_ask(self, flatbuff_msg, type_, dt_ts, symbol, req_status, dtype_)
        Processes bid/ask data and calls the appropriate method to handle the data.
    __process_marketdata_admin_reply(self, msg)
        Processes the market data admin reply received from the market data server.
    handle_marketsub_data(self, socket)
        Handles data received on the subscription socket for market data updates.
    handle_marketserver_data(self, socket)
        Handles data received on the dealer socket for market data updates.
    marketdata_login(self, socket)
        Sends a login request to the market data server.
    query_bidask_snapshot(self, symbol)
        Sends a request for a bid/ask snapshot for a specific symbol.
    query_instrument_status(self, symbol)
        Sends a request for the instrument status of a specific symbol.
    """

    def __init__(self, config_path):
        """
        Initializes the MarketDataServerClient instance.

        Sets up the configuration from the provided path, initializes market data server communication sockets,
        and prepares dictionaries for symbol mappings.

        Parameters
        ----------
        config_path : str
            Path to the configuration file used for setting up the market data server connection.
        """
        
        ##
        super().__init__(config_path)

        ##
        self.md_config = ConfigObjectClass(config_path) 
        self.marketdata_server_init()
        
        ##
        self.__market_date_instrument_status = {y:x for x,y in marketDataServer.MarketDataInstrumentStatus.__dict__.items() if not x.startswith('__')}
        self.__market_data_request_status = {y:x for x,y in marketDataServer.MarketDataRequestStatus.__dict__.items() if not x.startswith('__')}
        self.__data_action = {y:x for x,y in marketDataServer.DataAction.__dict__.items() if not x.startswith('__')}
        # self.__market_type = {y:x for x,y in marketDataServer.MarketType.__dict__.items() if not x.startswith('__')}        
        # self.__side = {y:x for x,y in marketDataServer.Side.__dict__.items() if not x.startswith('__')}
        
        ##        
        self.SEND_QUEUE: Queue = Queue()
        self.SYMBOL_ID_MAPPING = dict()
        self.SYMBOL_NAME_MAPPING = dict()
        self.SYMBOL_EXCHANGE_MAPPING = dict()
    
    ##
    def marketdata_server_init(self):
        
        ##
        identity = str(self.md_config.strategy_id).encode('utf-8')
        for region in self.md_config.region_ip_config.keys():
            # No MD in PAPER region
            if region == "PAPER":
                continue
                
            ##
            self.MD_DEALER_DICT[region] = self.ZMQ_CONTEXT.socket(zmq.DEALER)
            self.MD_DEALER_DICT[region].setsockopt(zmq.IDENTITY, identity)
            self.MD_DEALER_DICT[region].setsockopt(zmq.HEARTBEAT_IVL, int(self.md_config.hearbeat_interval*1000))
            self.MD_DEALER_DICT[region].setsockopt(zmq.HEARTBEAT_TIMEOUT, int(self.md_config.heartbeat_timeout*1000))
            
            self.MD_DEALER_DICT[region].RCVTIMEO = int(self.md_config.connection_timeout * 1000)
            self.md_config.masterlog.info("Connecting to market data server request socket")
            self.MD_DEALER_DICT[region].connect(self.md_config.region_ip_config[region]['MARKET_DATA_SERVER_ROUTER'])

            monitor_socket = self.MD_DEALER_DICT[region].get_monitor_socket()
            
            self.ZMQ_CALLBACK_DICT[monitor_socket] = event_monitoring
            self.ZMQ_CALLBACK_DICT[self.MD_DEALER_DICT[region]] = self.handle_marketserver_data
            
            self.ALL_SOCKET_LIST.append(self.MD_DEALER_DICT[region])
            self.ALL_SOCKET_LIST.append(monitor_socket)
            
            self.SOCKET_INFO_DICT[self.MD_DEALER_DICT[region].underlying] = {'name': 'market_data_server_dealer_socket', "type": "market_data_server", "region": region}
            self.SOCKET_INFO_DICT[monitor_socket.underlying] = {'name': 'market_data_server_monitor_socket', "type": "monitor", "region": region}
            
            # MD LOG IN
            self.marketdata_login(socket=self.MD_DEALER_DICT[region])
            
            ##
            self.MD_SUB_DICT[region] = self.ZMQ_CONTEXT.socket(zmq.SUB)
            self.MD_SUB_DICT[region].connect(self.md_config.region_ip_config[region]['MARKET_DATA_SERVER_PUBSUB'])
            
            self.ZMQ_CALLBACK_DICT[self.MD_SUB_DICT[region]] = self.handle_marketsub_data
            
            ##
            self.ALL_SOCKET_LIST.append(self.MD_SUB_DICT[region])
            
            ##
            self.SOCKET_INFO_DICT[self.MD_SUB_DICT[region].underlying] = {'name': 'market_data_server_sub_socket', "type": "market_data_server", "region": region}
            
    
    def marketdata_logout(self, dealer_socket: zmq.Socket, sub_socket: zmq.Socket):

        builder = flatbuffers.Builder(2048)

        marketDataServer.LogOutRequestMessageStart(builder)
        marketDataServer.LogOutRequestMessageAddClientId(builder, self.md_config.client_id)
        marketDataServer.LogOutRequestMessageAddStrategyId(builder, self.md_config.strategy_id)
        log_out_request_message = marketDataServer.LogOutRequestMessageEnd(builder)

        ###
        logout_admin_union = marketDataServer.AdminRequestUnion.logOutRequestMessage
        marketDataServer.AdminRequestMessageStart(builder)
        marketDataServer.AdminRequestMessageAddAdminRequestUnionType(builder, logout_admin_union)
        marketDataServer.AdminRequestMessageAddAdminRequestUnion(builder, log_out_request_message)
        admin_request_message = marketDataServer.AdminRequestMessageEnd(builder)
        
        message_request_union = marketDataServer.MessageRequestUnion.adminRequestMessage
        marketDataServer.MarketDataServerRequestMessageStart(builder)
        marketDataServer.MarketDataServerRequestMessageAddMessageRequestUnionType(builder, message_request_union)
        marketDataServer.MarketDataServerRequestMessageAddMessageRequestUnion(builder, admin_request_message)
        market_data_server_request_message = marketDataServer.MarketDataServerRequestMessageEnd(builder)

        builder.Finish(market_data_server_request_message)
        buf = builder.Output()

        self.md_config.masterlog.info(f"Sending LogOutRequestMessage to MarketDataServer")
        dealer_socket.send(buf)
        
        recv_buf = dealer_socket.recv()
        self.md_config.masterlog.info(f"Received LogOutReplyMessage from MarketDataServer")

        logout_server_reply = marketDataServer.MarketDataServerReplyMessage.GetRootAs(recv_buf, 0)

        admin_reply = marketDataServer.AdminReplyMessage()
        admin_reply.Init(logout_server_reply.MessageReplyUnion().Bytes, logout_server_reply.MessageReplyUnion().Pos)

        ##
        logout_reply = marketDataServer.LogOutReplyMessage()
        logout_reply.Init(admin_reply.AdminReplyUnion().Bytes, admin_reply.AdminReplyUnion().Pos)

        if logout_reply.LogOutStatus() == marketDataServer.LogOutStatus.SUCCESS:
            self.md_config.masterlog.info(f"MarketDataServer Logout reply. Client: {logout_reply.ClientId()} STATUS: SUCCESS")
            dealer_socket.close()
            sub_socket.close()
            
        else:
            self.md_config.masterlog.critical(f"MarketDataServer Logout reply. Client: {logout_reply.ClientId()} STATUS: FAILURE")
        
    @abstractmethod
    def on_trade_data(self, timestamp, symbol, price, size, open_interest):
        """
        Abstract method to be implemented by user for processing trade data received from the market data server.

        Parameters
        ----------
        timestamp: datetime.datetime.utcfromtimestamp
            The UTC timestamp of the data.
        symbol : str | int
            The trading symbol for which the data is received.
        price : float
            The price of the data.
        size : float
            The size of the data.
        open_interest : float
            The open interest of the data.
        """
        pass
    
    @abstractmethod
    def on_ohlcv_data(self, start_ts, end_ts, symbol, open, high, low, close, volume, open_interest):
        """
        Abstract method to be implemented by user for processing OHLCV data received from the market data server.

        Parameters
        ----------
        start_ts : datetime.datetime.utcfromtimestamp
            The UTC timestamp of the start of the data.
        end_ts : datetime.datetime.utcfromtimestamp
            The UTC timestamp of the end of the data.
        symbol : str | int
            The trading symbol for which the data is received.
        open : float
            The open price of the data.
        high : float
            The high price of the data.
        low : float
            The low price of the data.
        close : float
            The close price of the data.
        volume : float
            The volume of the data.
        open_interest : float
            The open interest of the data.
        """
        pass
    
    
    @abstractmethod
    def on_bidask_data(self, timestamp, symbol, status, price, size, data_action, side, data_type):
        """
        Abstract method to be implemented by user for processing bid/ask data received from the market data server.

        Parameters
        ----------
        timestamp : datetime.datetime.utcfromtimestamp
            The UTC timestamp of the data.
        symbol : str | int
            The trading symbol for which the data is received.
        status : str
            The status of the request. Either 'SUCCESS' or 'FAILURE'.
        price : float
            The price of the data.
        size : float
            The size of the data.
        data_action : str
            The action of the data. Either 'NEW', 'CHANGE', or 'DELETE'.
        side : str. "BID" | "ASK"
            The side of the order book. Either 'BID' or 'ASK'.
        data_type : str. "INCREMENTAL" | "SNAPSHOT"
            The type of the data. Either 'INCREMENTAL' or 'SNAPSHOT'.
        """
        pass
            
    @abstractmethod
    def on_instrument_status(self, timestamp, symbol, symbol_status, symbol_status_code, req_status):
        """
        Abstract method for processing instrument status data received from the market data server.

        Parameters
        ----------
        timestamp : datetime.datetime.utcfromtimestamp
            The UTC timestamp of the data.
        symbol : str | int
            The trading symbol for which the data is received.
        symbol_status : str
            The status of the symbol. Either 'TRADING_HALTED', 'AVAILABLE_TO_TRADE', 'UNAVAILABLE_TO_TRADE', 'PRE_OPEN', 'FAST_MARKET', 'POST_CLOSE', 'PRE_TRADE', or 'UNKNOWN'.
        symbol_status_code : int
            The code of the symbol status.
        req_status : str
            The status of the request. Either 'SUCCESS' or 'FAILURE'.
        """
        pass
        
        
    
    def __process_bid_ask(self, flatbuff_msg, type_, dt_ts, symbol, req_status, dtype_):
        assert type_ in ['BID', 'ASK'], "type_ must be either 'BID' or 'ASK'"
        assert dtype_ in ['INCREMENTAL', 'SNAPSHOT'], "dtype_ must be either 'INCREMENTAL' or 'SNAPSHOT'"
        attr_ = 'Bid' if type_ == 'BID' else 'Ask'
        
        ##
        length_ = flatbuff_msg.BidLength() if type_ == 'BID' else flatbuff_msg.AskLength()
        for i in range(length_):
            price_mantissa, price_exp = getattr(flatbuff_msg, attr_)(i).PriceMantissa(), getattr(flatbuff_msg, attr_)(i).PriceExponent()
            size_mantissa, size_exp = getattr(flatbuff_msg, attr_)(i).SizeMantissa(), getattr(flatbuff_msg, attr_)(i).SizeExponent()
            data_action = self.__data_action[getattr(flatbuff_msg, attr_)(i).Action()]        

            msg_ = f"Symbol: {symbol}, Timestamp: {dt_ts}, Side: {type_}, Price: {price_mantissa * (10 ** price_exp)}, Size: {size_mantissa * (10 ** size_exp)}, Data Action: {data_action}"
            self.md_config.masterlog.debug(msg_)

            price = price_mantissa * (10 ** price_exp)
            price = round(price, abs(price_exp))
            
            size = size_mantissa * (10 ** size_exp)
            
            ##
            self.on_bidask_data(timestamp=dt_ts, symbol=symbol, status=req_status, price=price, size=size, data_action=data_action, side=type_, data_type=dtype_)

    
    def __process_marketdata_admin_reply(self, msg):
        """
        Processes the market data received from the market data server.

        Handles different types of market data replies, including incremental updates, trade data, and bid/ask snapshots.

        Parameters
        ----------
        msg :
            The message received from the market data server.
        """        
        msg = marketDataServer.MarketDataServerReplyMessage.GetRootAs(msg, 0)
        marketData = marketDataServer.MarketDataReplyMessage()
        marketData.Init(msg.MessageReplyUnion().Bytes, msg.MessageReplyUnion().Pos)
                
        if marketData.MarketDataReplyUnionType() == marketDataServer.MarketDataReplyUnion.incremental:
            incremental = marketDataServer.Incremental()
            incremental.Init(marketData.MarketDataReplyUnion().Bytes, marketData.MarketDataReplyUnion().Pos)

            bid_length, ask_length = incremental.BidLength(), incremental.AskLength()
            symbol = self.SYMBOL_NAME_MAPPING.get(incremental.SymbolId(), None)
            timestamp = incremental.Timestamp()
            dt_ts = dt.datetime.fromtimestamp(timestamp // 1000000000)

            #
            if dt_ts < dt.datetime(2000, 1, 1):
                dt_ts = dt.datetime.utcnow()

            self.__process_bid_ask(incremental, 'BID', dt_ts, symbol, 'SUCCESS', 'INCREMENTAL')
            self.__process_bid_ask(incremental, 'ASK', dt_ts, symbol, 'SUCCESS', 'INCREMENTAL')
            
                
        elif marketData.MarketDataReplyUnionType() == marketDataServer.MarketDataReplyUnion.tradeData:
            tradeData = marketDataServer.TradeData()
            tradeData.Init(marketData.MarketDataReplyUnion().Bytes, marketData.MarketDataReplyUnion().Pos)
            
            ##
            timestamp = tradeData.Timestamp()
            dt_ts = dt.datetime.fromtimestamp(timestamp // 1000000000)
            symbol = self.SYMBOL_NAME_MAPPING.get(tradeData.SymbolId(), None)
            open_interest = tradeData.OpenInterest()

            length_ = tradeData.TradeLength()
            for i in range(length_):
                price_mantissa, price_exp = tradeData.Trade(i).PriceMantissa(), tradeData.Trade(i).PriceExponent()
                size_mantissa, size_exp = tradeData.Trade(i).SizeMantissa(), tradeData.Trade(i).SizeExponent()
                data_action = self.__data_action[tradeData.Trade(i).Action()]

                price = price_mantissa * (10 ** price_exp)
                price = round(price, abs(price_exp))
                
                size = size_mantissa * (10 ** size_exp)
                
                msg_ = f"Symbol: {symbol}, Timestamp: {dt_ts}, Price: {price}, Size: {size}, Data Action: {data_action}"
                self.md_config.masterlog.debug(msg_)

                self.on_trade_data(dt_ts, symbol, price, size, open_interest)
            
        elif marketData.MarketDataReplyUnionType() == marketDataServer.MarketDataReplyUnion.bidAskSnapshot:
            snapshot = marketDataServer.BidAskSnapshot()
            snapshot.Init(marketData.MarketDataReplyUnion().Bytes, marketData.MarketDataReplyUnion().Pos)
            
            bid_length, ask_length = snapshot.BidLength(), snapshot.AskLength()
            symbol = self.SYMBOL_NAME_MAPPING.get(snapshot.SymbolId(), None)
            req_status = self.__market_data_request_status[snapshot.Status()]
            timestamp = snapshot.Timestamp()
            dt_ts = dt.datetime.fromtimestamp(timestamp // 1000000000)
            
            if dt_ts < dt.datetime(2000, 1, 1):
                dt_ts = dt.datetime.utcnow()
                        
            msg_ = f"SNAPSHOT RECEIVED: Symbol: {symbol}, Timestamp: {dt_ts}, Request Status: {req_status}, bid length: {bid_length}, ask length: {ask_length}"
            self.md_config.masterlog.debug(msg_)
            
            self.__process_bid_ask(snapshot, 'BID', dt_ts, symbol, req_status, 'SNAPSHOT')
            self.__process_bid_ask(snapshot, 'ASK', dt_ts, symbol, req_status, 'SNAPSHOT')

                
        elif marketData.MarketDataReplyUnionType() == marketDataServer.MarketDataReplyUnion.instrumentStatus:
            
            instrument_status_msg = marketDataServer.InstrumentStatus()
            instrument_status_msg.Init(marketData.MarketDataReplyUnion().Bytes, marketData.MarketDataReplyUnion().Pos)
            
            ##
            symbol = self.SYMBOL_NAME_MAPPING.get(instrument_status_msg.SymbolId(), None)
            timestamp = instrument_status_msg.Timestamp()
            dt_ts = dt.datetime.fromtimestamp(timestamp // 1000000000)

            symbol_status_code = instrument_status_msg.InstrumentStatus()
            symbol_status = self.__market_date_instrument_status[symbol_status_code]

            ##
            self.md_config.masterlog.debug("Received Instrument Status")
            self.md_config.masterlog.debug(f"Symbol ID: {instrument_status_msg.SymbolId()}")
            self.md_config.masterlog.debug(f"Strategy ID: {instrument_status_msg.StrategyId()}")
            self.md_config.masterlog.debug(f"Client ID: {instrument_status_msg.ClientId()}")
            self.md_config.masterlog.debug(f"Timestamp: {dt_ts}")
            self.md_config.masterlog.debug(f"Market Data Status: {symbol_status}")
            
            status = instrument_status_msg.Status()
            if status == marketDataServer.MarketDataRequestStatus.SUCCESS:
                self.md_config.masterlog.debug("Status: SUCCESS")
                status = "SUCCESS"
                            
            else:
                self.md_config.masterlog.debug("Status: FAILURE")
                status = "FAILURE"
            
            self.on_instrument_status(dt_ts, symbol, symbol_status, symbol_status_code, status)
        
        else:
            raise ValueError("Unknown Market Data Type")
    
    
    def handle_marketsub_data(self, socket: zmq.Socket):
        """
        Handles the market data received from the subscribed socket.

        Processes data received on the subscription socket for market data updates.

        Parameters
        ----------
        socket : zmq.Socket
            The ZeroMQ subscription socket used for receiving market data updates.
        """
        [id_, msg] = socket.recv_multipart()
        self.__process_marketdata_admin_reply(msg)

    def handle_marketserver_data(self, socket: zmq.Socket):
        """
        Handles the market data received from the dealer socket.

        Processes data received on the dealer socket for market data updates.

        Parameters
        ----------
        socket : zmq.Socket
            The ZeroMQ dealer socket used for sending requests to the market data server.
        """

        msg = socket.recv_multipart()
        msg = msg[0]
        self.__process_marketdata_admin_reply(msg)
    

    def marketdata_login(self, socket: zmq.Socket):
        """
        Sends a login request to the market data server and waits for a login reply.        
        
        Parameters
        ----------
        socket : zmq.sugar.socket.Socket
            The ZeroMQ dealer socket used for sending requests to the market data server.
        """
        builder = flatbuffers.Builder(2048)

        marketDataServer.LogInRequestMessageStart(builder)
        marketDataServer.LogInRequestMessageAddClientId(builder, self.md_config.client_id)
        marketDataServer.LogInRequestMessageAddStrategyId(builder, self.md_config.strategy_id)
        logInMsg = marketDataServer.LogInRequestMessageEnd(builder)

        marketDataServer.AdminRequestMessageStart(builder)
        marketDataServer.AddAdminRequestUnionType(builder, marketDataServer.AdminRequestUnion.logInRequestMessage)
        marketDataServer.AddAdminRequestUnion(builder, logInMsg)
        adminMsg = marketDataServer.AdminRequestMessageEnd(builder)

        marketDataServer.MarketDataServerRequestMessageStart(builder)
        marketDataServer.AddMessageRequestUnionType(builder, marketDataServer.MessageRequestUnion.adminRequestMessage)
        marketDataServer.AddMessageRequestUnion(builder, adminMsg)
        requestMsg = marketDataServer.MarketDataServerRequestMessageEnd(builder)
        builder.Finish(requestMsg)
        buf = builder.Output()

        self.md_config.masterlog.info('Sending Market Data Server Log In Request')
        socket.send(buf)

        binBuffer = socket.recv()
        self.md_config.masterlog.info('Received Market Data Server Log In Reply')

        m = marketDataServer.MarketDataServerReplyMessage.GetRootAs(binBuffer, 0)
        adminReplyMessage = marketDataServer.AdminReplyMessage()
        adminReplyMessage.Init(m.MessageReplyUnion().Bytes, m.MessageReplyUnion().Pos)

        loginReply = marketDataServer.LogInReplyMessage()
        loginReply.Init(adminReplyMessage.AdminReplyUnion().Bytes, adminReplyMessage.AdminReplyUnion().Pos)

        self.md_config.masterlog.info('Market Data Server Client ID: {}'.format(self.md_config.strategy_id))

    def query_bidask_snapshot(self, symbol):
        """
        Sends a bid ask snapshot request to the market data server for a specific symbol.
       
        Parameters
        ----------
        symbol:
            Symbol for which the snapshot is requested. But it should in `trading_universe` list.
        
        """
        
        symbol_id = self.SYMBOL_ID_MAPPING.get(symbol, None)
        exchange = self.SYMBOL_EXCHANGE_MAPPING.get(symbol, None)
        region = self.md_config.md_exchange_region_mapping.get(exchange, None)

        assert isinstance(symbol_id, int), "symbol not found in trading universe"
        
        builder = flatbuffers.Builder(2048)
        
        marketDataServer.MarketDataRequestMessageStart(builder)
        marketDataServer.AddMarketDataRequestType(builder, marketDataServer.MarketDataRequestType.SNAPSHOT )
        marketDataServer.MarketDataRequestMessageAddSymbolId(builder, symbol_id)
        marketDataServer.MarketDataRequestMessageAddStrategyId(builder, self.md_config.strategy_id)
        marketDataServer.MarketDataRequestMessageAddClientId(builder, self.md_config.client_id)
        dataRequest = marketDataServer.MarketDataRequestMessageEnd(builder)

        marketDataServer.MarketDataServerRequestMessageStart(builder)
        marketDataServer.MarketDataServerRequestMessageAddMessageRequestUnionType(builder, marketDataServer.MessageRequestUnion.marketDataRequestMessage)
        marketDataServer.MarketDataServerRequestMessageAddMessageRequestUnion(builder, dataRequest)
        requestMsg = marketDataServer.MarketDataServerRequestMessageEnd(builder)

        builder.Finish(requestMsg)
        buf = builder.Output()
        
        socket = self.MD_DEALER_DICT[region]
        self.SEND_QUEUE.put((socket, buf))


    def query_instrument_status(self, symbol):
        """
        Sends a request to the market data server to get the status of a specified instrument.

        Parameters
        ----------
        symbol : str
            The trading symbol for which the instrument status is requested.
        """        
        
        symbol_id = self.SYMBOL_ID_MAPPING.get(symbol, None)
        exchange = self.SYMBOL_EXCHANGE_MAPPING.get(symbol, None)
        region = self.md_config.md_exchange_region_mapping.get(exchange, None)

        assert isinstance(symbol_id, int), "Symbol ID must be an integer"
        
        ##
        builder = flatbuffers.Builder(2048)
        
        marketDataServer.MarketDataRequestMessageStart(builder)
        marketDataServer.AddMarketDataRequestType(builder, marketDataServer.MarketDataRequestType.INSTRUMENT_STATUS)
        marketDataServer.MarketDataRequestMessageAddSymbolId(builder, symbol_id)
        marketDataServer.MarketDataRequestMessageAddStrategyId(builder, self.md_config.strategy_id)
        marketDataServer.MarketDataRequestMessageAddClientId(builder, self.md_config.client_id)
        dataRequest = marketDataServer.MarketDataRequestMessageEnd(builder)

        marketDataServer.MarketDataServerRequestMessageStart(builder)
        marketDataServer.MarketDataServerRequestMessageAddMessageRequestUnionType(builder, marketDataServer.MessageRequestUnion.marketDataRequestMessage)
        marketDataServer.MarketDataServerRequestMessageAddMessageRequestUnion(builder, dataRequest)
        requestMsg = marketDataServer.MarketDataServerRequestMessageEnd(builder)

        builder.Finish(requestMsg)
        buf = builder.Output()
        
        socket = self.MD_DEALER_DICT[region]
        self.SEND_QUEUE.put((socket, buf))
    