
import zmq
import signal
import sys
import threading
import time

from pythonclient.utils import timeout, event_monitoring
from pythonclient.marketDataServerClient import MarketDataServerClient

class TradingClient(MarketDataServerClient):

    def __init__(self, config_path: str):
        """
        Initialize the TradingClient instance.

        Parameters
        ----------
        config_path : str
            Path to the configuration file.

        Attributes
        ----------
        socket_dict : dict
            A dictionary to keep track of all sockets, with the socket underlying as the key
            and a dictionary with the socket name as the value.

        all_socket_list : list
            A list to store all the sockets.
        _STRATEGY_STATE_DICT : dict
            Dictionary to store strategy states.
        zmq_context : zmq.Context
            ZeroMQ context for socket communication.
        """        
        
        super().__init__(config_path)
                
        ### Keeping track of all the sockets
        self.socket_dict = dict() # key: socket_underlying, value: dict{name: socket_name}
        self.all_socket_list = list()
        self._STRATEGY_STATE_DICT = {}

        signal.signal(signal.SIGINT, self.shutdown_and_exit)

        self.startup_init()
        
    def startup_init(self):
        """
        Initialize the startup process, preparing sockets, setting up polling,
        and registering callbacks. Also requests all open orders.
        """
        
        self.prepare_sockets()
        self.setup_socket_polling()
        self.register_callbacks()
        
        ## Get all open orders
        self.request_all_active_orders(isManual=False)
        
    def shutdown_and_exit(self, signum, frame):
        """
        Handles shutdown procedure and exits the program when SIGINT, i.e CTRL + C is received.

        Parameters
        ----------
        signum : int
            Signal number.
        frame : Frame
            Frame object.
        """
       
        self.config.masterlog.critical("Logging out. CTRL + C was pressed")

        self.trading_server_log_out()
        self.market_data_server_log_out()
        self.gui_server_log_out()
        
        if hasattr(self, 'zmq_context'):
            self.zmq_context.destroy()
        
        sys.exit(0)

    def subscribe_data(self, symbol_id_ls):
        """
        Subscribes to data based on the provided symbol ID list.

        Parameters
        ----------
        symbol_id_ls : list
            List of symbol IDs to subscribe or unsubscribe.

        Raises
        ------
        ValueError
            If `symbol_id_ls` is empty.
        
        AssertionError
            If `symbol_id_ls` is not a list.
        """

        assert isinstance(symbol_id_ls, list), "symbol_id_ls must be a list"
        
        if len(symbol_id_ls) == 0:
            raise ValueError("symbol_id_ls is empty")
    
        for sym_id in symbol_id_ls:
            hexTopic = hex(sym_id)[2:]
            self.market_data_server_sub_socket.setsockopt(zmq.SUBSCRIBE, hexTopic.encode('utf-8'))
            self.config.masterlog.info(f"Subscribing to {sym_id}")
    

    def prepare_sockets(self):
        """
        Prepares and connects all required sockets for trading, market data, and GUI server.
        Also logs in to each server.
        """
        
        # trading server
        self.zmq_context = zmq.Context()

        self.trading_server_dealer_socket = self.zmq_context.socket(zmq.DEALER)
        self.trading_server_dealer_socket.setsockopt(zmq.IDENTITY, str(self.config.strategy_id).encode('utf-8'))
        self.trading_server_dealer_socket.RCVTIMEO = int(self.config.connection_timeout * 1000)
        self.config.masterlog.info("Connecting to trading server request socket")
        self.trading_server_dealer_socket.connect(self.config.trading_server_router)

        self.trading_server_monitor_socket = self.trading_server_dealer_socket.get_monitor_socket()        
        self.config.masterlog.info("Logging in to trading server")
        self.trading_server_log_in()
        
        self.all_socket_list.append(self.trading_server_dealer_socket)
        self.all_socket_list.append(self.trading_server_monitor_socket)

        self.socket_dict[self.trading_server_dealer_socket.underlying] = {'name': 'trading_server_dealer_socket'}
        self.socket_dict[self.trading_server_monitor_socket.underlying] = {'name': 'trading_server_monitor_socket'}


        # market data server
        self.market_data_server_dealer_socket = self.zmq_context.socket(zmq.DEALER)
        self.config.masterlog.info("Connecting to market data server request socket")
        self.market_data_server_dealer_socket.setsockopt(zmq.IDENTITY, str(self.config.strategy_id).encode('utf-8'))
        self.market_data_server_dealer_socket.RCVTIMEO = int(self.config.connection_timeout * 1000)
        self.market_data_server_dealer_socket.connect(self.config.market_data_server_router)

        self.market_data_server_monitor_socket = self.market_data_server_dealer_socket.get_monitor_socket()
        
        self.config.masterlog.info("Logging in to market data server")
        self.market_data_server_log_in()
        
        self.all_socket_list.append(self.market_data_server_dealer_socket)
        self.all_socket_list.append(self.market_data_server_monitor_socket)

        self.socket_dict[self.market_data_server_dealer_socket.underlying] = {'name': 'market_data_server_dealer_socket'}
        self.socket_dict[self.market_data_server_monitor_socket.underlying] = {'name': 'market_data_server_monitor_socket'}

        self.market_data_server_sub_socket = self.zmq_context.socket(zmq.SUB)
        self.config.masterlog.info("Connecting to market data server subscription socket")
        self.market_data_server_sub_socket.connect(self.config.market_data_server_pubsub)
        
        self.all_socket_list.append(self.market_data_server_sub_socket)
        self.socket_dict[self.market_data_server_sub_socket.underlying] = {'name': 'market_data_server_sub_socket'}

        # GUI Server Request Socket
        self.config.masterlog.info("Connecting to GUI server request socket")
        self.gui_server_dealer_socket = self.zmq_context.socket(zmq.DEALER)
        self.gui_server_dealer_socket.setsockopt(zmq.IDENTITY, str(self.config.strategy_id).encode('utf-8'))
        self.gui_server_dealer_socket.RCVTIMEO = int(self.config.connection_timeout * 1000)
        self.gui_server_dealer_socket.connect(self.config.gui_server_router)
        
        self.gui_server_monitor_socket = self.gui_server_dealer_socket.get_monitor_socket()
        
        self.config.masterlog.info("Logging in to GUI server")
        self.gui_server_log_in()

        self.all_socket_list.append(self.gui_server_dealer_socket)
        self.all_socket_list.append(self.gui_server_monitor_socket)

        self.socket_dict[self.gui_server_dealer_socket.underlying] = {'name': 'gui_server_dealer_socket'}
        self.socket_dict[self.gui_server_monitor_socket.underlying] = {'name': 'gui_server_monitor_socket'}
        

    def register_callbacks(self):
        """
        Registers callbacks for different sockets to handle server updates, socket monitoring, market data, and GUI responses.
        """
        
        self.config.masterlog.info("Registering callbacks")
        self.callbacks = dict()
        self.callbacks[self.trading_server_dealer_socket] = self.handle_trading_server_update
        self.callbacks[self.market_data_server_sub_socket] = self.handle_market_sub_data
        self.callbacks[self.market_data_server_dealer_socket] = self.handle_market_server_update
        
        self.callbacks[self.trading_server_monitor_socket] = event_monitoring
        self.callbacks[self.market_data_server_monitor_socket] = event_monitoring

        self.callbacks[self.gui_server_dealer_socket] = self.on_GUI_response
        self.callbacks[self.gui_server_monitor_socket] = event_monitoring
        
    def setup_socket_polling(self):
        """
        Sets up socket polling for all registered sockets to listen for incoming messages.
        """
        
        self.config.masterlog.info("Registering poller")

        self.poller = zmq.Poller()
        for sock in self.all_socket_list:
            self.config.masterlog.info("Registering poller for socket: {}".format(self.socket_dict[sock.underlying]['name']))
            self.poller.register(sock, zmq.POLLIN)

    ##
    def check_and_handle_messages(self):
        """
        Checks and handles messages from all sockets in a loop. Breaks the loop if no messages are received.
        """
        
        cnt = 0
        while True:
            cnt += 1
            received_message = False
            socks = dict(self.poller.poll(timeout=0))
            
            for sock, status in socks.items():
                if status == zmq.POLLIN:
                    received_message = True
                    
                    socket_name = self.socket_dict[sock.underlying]['name']
                    self.config.masterlog.debug(f"{cnt}: Received message from socket: {socket_name}")
                    
                    callback = self.callbacks[sock]
                    
                    if socket_name in ["trading_server_monitor_socket", 
                                    "market_data_server_monitor_socket", 
                                    "gui_server_monitor_socket"]:
                        callback(sock, self.config)
                    else:
                        callback()

            if not received_message:
                break





