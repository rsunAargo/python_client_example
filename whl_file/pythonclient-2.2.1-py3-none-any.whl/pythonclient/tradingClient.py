
import threading
import signal
import sys
import time
import traceback
import datetime as dt
from pythonclient.utils import process_bid_ask_msg

from pythonclient.tradingClientBase import TradingClientBase


class TradingClient(TradingClientBase):

    """
    The TradingClient class is the main class that should be used to interact with the trading server. It inherits from the TradingClientBase class.
    
    It is used to place orders, cancel orders, get order details, get position details, etc.
    
    Main purpose to give REST like functionality to the user.
    
    Attributes
    ----------
    path : str
        Path to the config file.
    
    tradingUniverse : list
        Symbol universe.
    
    symbolSource : str
        For detailed information on possible values, see :ref:`variable_documentation`.

    Examples
    --------
    Here's an example of how to init `TradingClient`:

    .. code-block:: python

        # Init TradingClient
        from pythonclient.tradingClient import TradingClient
        
        client = TradingClient(path="config.json", tradingUniverse=['ESZ3', 'RTYZ3'], symbolSource="SYMBOL_RIC")

    """
    
    
    def __init__(self, path, tradingUniverse: list, symbolSource: str) -> None:
        super().__init__(path, tradingUniverse, symbolSource)
        
        assert isinstance(tradingUniverse, list), "tradingUniverse must be a list"
        assert len(set(tradingUniverse)) == len(tradingUniverse), "tradingUniverse must be a list of unique integers"
        
        self.tradingUniverse = tradingUniverse
        self.KEEP_RUNNING = True
        self.ORDER_ID = 100
        
        self.t1 = threading.Thread(target=self.send_and_receive_messages, args=())
        self.t1.start()
    
        signal.signal(signal.SIGINT, self.shutdown_and_exit)
        
        ## INTI SNAPSHOT/INCREMENTAL MSGs 
        self.SNAPSHOT_STATUS_DICT = {} # symbol: True/False
        self.BID_DICT = {} # symbol: SortedDict
        self.ASK_DICT = {} # symbol: SortedDict
        self.REQ_STATUS = None # SUCCESS/FAILURE
    
    def on_data(self, data_dict):
        
        if data_dict['DATA_TYPE'] in ['SNAPSHOT', 'INCREMENTAL']:
            self.REQ_STATUS = data_dict.get("STATUS", "SUCCESS")
            self.ASK_DICT, self.BID_DICT, self.SNAPSHOT_STATUS_DICT = process_bid_ask_msg(data_dict, self.BID_DICT, self.ASK_DICT, self.SNAPSHOT_STATUS_DICT)
            
            if data_dict['DATA_TYPE'] == 'INCREMENTAL':            
                self.ASK_DICT['LAST_UPDATE'] = dt.datetime.utcnow()
                self.BID_DICT['LAST_UPDATE'] = dt.datetime.utcnow()
            
    
    def on_position_update(self, dict_):
        pass
    
    def shutdown_and_exit(self, signum, frame):
        """
        Handles shutdown procedure and exits the program when SIGINT, i.e CTRL + C is received or when user calls this function.
        Client will log out from the all the server and close all the sockets.

        Parameters
        ----------
        signum : int
            Signal number.
        frame : Frame
            Frame object.
        
        Examples
        --------
        Here's an example of how to use `place_order`:

        .. code-block:: python

            client.shutdown_and_exit(None, None)
                    
        """
        self.KEEP_RUNNING = False
        
        self.t1.join()
        
        self.config.masterlog.critical(f"Logging out. CTRL + C was pressed: signum={signum}, frame={frame}")

        ## log out TS
        for key in self.TS_DEALER_DICT.keys():
            self.trading_server_log_out(socket=self.TS_DEALER_DICT[key])
            
        # log out MD
        for key in self.MD_DEALER_DICT.keys():
            self.market_data_server_log_out(dealer_socket=self.MD_DEALER_DICT[key], sub_socket=self.MD_SUB_DICT[key])
                
        if hasattr(self, 'zmq_context'):
            self.zmq_context.destroy()
        
        if signum:
            self.config.masterlog.critical("CTRL + C was pressed. Exiting the program")
            sys.exit(0)
        
        else:
            self.config.masterlog.critical("Please press CTRL + C again to exit the program")
    
    
    #
    def __get_order_id(self) -> int:
        """
        Gets a unique order id to be used in `placeOrder`.

        Returns
        -------
        int
            Unique order id.
        """
        
        self.ORDER_ID += 1
        return self.ORDER_ID
        
    def placeOrder(self, symbol, side, size, priceType, timeInForce, price=None, stop_price=None, auto_cancel=True, is_manual=False):
        
        """
        Sends a new trading order to the trading server.

        Parameters
        ----------
        symbol : int | str
            Unique identifier of the trading symbol.
        side : str
            Order side, must be 'BUY' or 'SELL'.
        size : int
            Order size.
        priceType : str
            Type of the order price. For detailed information on possible values, see :ref:`variable_documentation`.
        timeInForce : str
            Time-in-force policy of the order. For detailed information on possible values, see :ref:`variable_documentation`.
        exchange : str
            Exchange of the symbol. For detailed information on possible values, see :ref:`variable_documentation`.
        price : float | None            
            Order price.
        stop_price : float | None            
            Stop Order price.
        auto_cancel : bool
            Flag indicating if the order should be automatically cancelled if client is disconnected from the trading server or python program crashes/closed.    
        is_manual : bool
            Flag indicating if the order is manually placed using python code.


        Raises
        ------
        AssertionError
            If any of the parameters do not conform to the expected type or set of values.
        ValueError
            If the symbol is not in the trading universe or if the strategy state is not started.
        TimeoutError
            If the response is not received within the timeout period.
        
        Returns
        -------
        order_id : int
            Identifier of the order that was sent. Use this identifier to get `UUID`.  

        Examples
        --------
        Here's an example of how to use `place_order`:

        .. code-block:: python

            # Placing Limit Order
            uuid = client.place_order(symbol="ESZ3", side='BUY', size=1, priceType='LIMIT', timeInForce='DAY', exchange='CME', price=3500.0)
            print(uuid)  # Expected output: 14713897
            
            # Placing Market Order
            uuid = client.place_order(symbol="ESZ3", side='BUY', size=1, priceType='MARKET', timeInForce='DAY', exchange='CME')
            print(uuid)  # Expected output: 147434
            
            # Placing Stop Order
            uuid = client.place_order(symbol="ESZ3", side='BUY', size=1, priceType='STOP', timeInForce='DAY', exchange='CME', stop_price=3500.0)
            print(uuid)  # Expected output: 14713897
            
        """
        
        order_id = self.__get_order_id()
        self.place_order(symbol=symbol, side=side, size=size, priceType=priceType, timeInForce=timeInForce, order_id=order_id, price=price, stop_price=stop_price, auto_cancel=auto_cancel, is_manual=is_manual)
        
        ##
        st_time = time.time()
        while True:
            uuid = self.get_uuid(order_id)
            if uuid is not None:
                return uuid

            if time.time() - st_time > self.config.response_timeout:
                raise TimeoutError(f"Response was not received. More than {self.config.response_timeout} seconds have passed.")

            # Sleep for 10 ms
            time.sleep(0.01)
    
    def getOrderDetail(self, uuid, exchange, forceRequest=False):
        """
        Gets the order details of a previously placed order. If the order details are not in the memory, it requests the order details from the trading server.

        Parameters
        ----------
        uuid : int
            Unique identifier of the order.
        exchange : str
            Exchange of the Order UUID. For detailed information on possible values, see :ref:`variable_documentation`.
        forceRequest : bool
            Flag indicating if the order details should be requested from the trading server, even if they are in the memory.

        Raises
        ------
        AssertionError
            If any of the parameters do not conform to the expected type or set of values.
        TimeoutError
            If the response is not received within the timeout period.
        
        Returns
        -------
        dict:
            - symbol: str | int 
                Similar to `symbolSource`
            - side: str
                'BUY' or 'SELL'
            - price: float | None
                Order price
            - size: int
                Order size
            - price_type: str
                Similar to `priceType`. For detailed information on possible values, see :ref:`variable_documentation`.
            - time_in_force: str
                Similar to `timeInForce`. For detailed information on possible values, see :ref:`variable_documentation`.
            - is_manual: bool
                Ignore this field
            - order_id: int
                Ignore this field
            - stop_price: float | None
                Stop Order price
            - executed_size: int
                Cumulative size of the order that has been executed
            - executed_price: float
                Average price of the order that has been executed
            - state: str
                State of the order. For detailed information on possible values, see :ref:`variable_documentation`.
            - rejection_code: int | None
                Rejection code of the order
            - rejection_reason: str | None
                Rejection reason of the order
            - uuid: int
                Unique identifier of the order given by the trading server. Use this to interact with the order.
            - timestamp: datetime.datetime UTC
                Timestamp


        Examples
        --------
        Here's an example of how to use `getOrderDetail`:

        .. code-block:: python
            
            uuid = client.getOrderDetail(uuid=14713897, exchange='CME')
            
        """
        
        assert uuid is not None, "uuid cannot be None"
        order_obj = self.get_order_details(uuid)
        
        if order_obj is None or forceRequest is True:
            self.request_order_status(uuid, exchange)
        
        st_time = time.time()
        while True and order_obj is None:
            order_obj = self.get_order_details(uuid)
            if order_obj is not None:
                break
                
            time.sleep(0.01)
            
            if time.time() - st_time > self.config.response_timeout:
                raise TimeoutError(f"Response was not received. More than {self.config.response_timeout} seconds have passed.")
        
        
        return {x:y for x, y in order_obj.__dict__.items() if not x.startswith('__')}
    
    
    ##
    def cancelOrder(self, uuid, exchange):
        """
        Cancels a previously placed order.

        Parameters
        ----------
        uuid : int
            Unique identifier of the order.
        exchange : str
            Exchange of the Order UUID. For detailed information on possible values, see :ref:`variable_documentation`.

        Raises
        ------
        TimeoutError
            If the response is not received within the timeout period.
        
        Returns
        -------
        dict:
            - symbol: str | int 
                Similar to `symbolSource`
            - side: str
                'BUY' or 'SELL'
            - price: float | None
                Order price
            - size: int
                Order size
            - price_type: str
                Similar to `priceType`. For detailed information on possible values, see :ref:`variable_documentation`.
            - time_in_force: str
                Similar to `timeInForce`. For detailed information on possible values, see :ref:`variable_documentation`.
            - is_manual: bool
                Ignore this field
            - order_id: int
                Ignore this field
            - stop_price: float | None
                Stop Order price
            - executed_size: int
                Cumulative size of the order that has been executed
            - executed_price: float
                Average price of the order that has been executed
            - state: str
                State of the order. For detailed information on possible values, see :ref:`variable_documentation`.
            - rejection_code: int | None
                Rejection code of the order
            - rejection_reason: str | None
                Rejection reason of the order
            - uuid: int
                Unique identifier of the order given by the trading server. Use this to interact with the order.
            - timestamp: datetime.datetime UTC
                Timestamp
                
        Examples
        --------
        Here's an example of how to use `cancelOrder`:

        .. code-block:: python
            
            uuid = client.cancelOrder(uuid=14713897, exchange='CME')
            
        """
        st_time = time.time()
        self.request_cancel_order(uuid, exchange)

        while True:
            order_obj = self.get_order_details(uuid)
            if order_obj is not None and order_obj.state in ['CANCELLED', "REJECTED", "FILLED", "UNACKED"]:
                break
            
            if time.time() - st_time > self.config.response_timeout:
                raise TimeoutError(f"Response was not received. More than {self.config.response_timeout} seconds have passed.")
                        
            time.sleep(0.01)
        
        return {x:y for x, y in order_obj.__dict__.items() if not x.startswith('__')}
    
    ##
    def getPosition(self, symbol):
        """
        Gets the position of a symbol.

        Parameters
        ----------
        symbol : int | str
            Unique identifier of the symbol.

        Raises
        ------
        TimeoutError
            If the response is not received within the timeout period.

        Returns
        -------
        dict
            - 'last_update': datetime.datetime.utcnow()
            - 'quantity': int
            - 'status': 'SUCCESS' | 'FAIL'
        
        Examples
        --------
        Here's an example of how to use `getPosition`:

        .. code-block:: python
            
            # When `symbol_source` is "SYMBOL_RIC"
            position_dict = client.getPosition(symbol="ESZ3")
            
            # When `symbol_source` is "SYMBOL_ID"
            position_dict = client.getPosition(symbol=68432)
            
        """
        
        req_time = dt.datetime.utcnow()
        st_time = time.time()
        assert symbol is not None, "symbol cannot be None"
        
        self.request_position(symbol)
        
        st_time = time.time()
        while True:
            position_dict = self.get_position(symbol)
            if position_dict is not None and position_dict['last_update'] > req_time:
                break
                
            time.sleep(0.01)
            
            if time.time() - st_time > self.config.response_timeout:
                raise TimeoutError(f"Response was not received. More than {self.config.response_timeout} seconds have passed.")
        
        
        return position_dict
    
    ##
    def cancelAllActiveOrders(self, exchange):
        """
        Cancels all active orders of the particular exchange. 
        
        Parameters
        ----------
        exchange : str
            Exchange of the Order UUID. For detailed information on possible values, see :ref:`variable_documentation`.
        
        Raises
        ------
        TimeoutError
            If the response is not received within the timeout period.
        
        Returns
        -------
        bool | dict
            True if successful
        
        Examples
        --------
        Here's an example of how to use `cancelAllActiveOrders`:

        .. code-block:: python
            
            # When `symbol_source` is "SYMBOL_RIC"
            status_ = client.cancelAllActiveOrders(exchange="CME")
                    
        """
        
        self.request_cancel_all_orders(exchange)
        
        st_time = time.time()
        while True:
            obj_ls = self.list_all_orders()
            if len(obj_ls) == 0:
                break
            
            for obj in obj_ls:
                
                if obj.exchange != exchange:
                    continue
                
                if obj.state not in ['FILLED', 'CANCELLED', 'REJECTED', 'UNACKED']: # Means order is still active
                    break
            
            else:
                return True
            
            if time.time() - st_time > self.config.response_timeout:
                raise TimeoutError(f"Response was not received. More than {self.config.response_timeout} seconds have passed.")
            
            time.sleep(0.01)
    
    ##
    def getAllOrders(self):
        """
        Gets all active orders currently in the memory.

        Returns
        -------
        list
            List of `getOrderDetail`.
        
        Examples
        --------
        Here's an example of how to use `getAllOrders`:

        .. code-block:: python
            
            all_order_dict = client.getAllOrders()

        """
        
        obj_ls = self.list_all_orders()
        dict_ls = []
        for obj in obj_ls:
            dict_ls.append({x:y for x, y in obj.__dict__.items() if not x.startswith('__')})
        
        return dict_ls
    
    
    ##
    def updateSymbolState(self, symbol, state):
        """
        Updates the state of a symbol. Must be either 'START' OR 'STOP'.
        If the state is 'start', you can place order for those symbols.

        Parameters
        ----------
        symbol : int | str
            Unique identifier of the symbol.
        state : str
            'START' OR 'STOP'.

        Returns
        -------
        bool
            True if successful, False otherwise.
        
        Raises
        ------
        AssertionError
            If the state is not 'START' or 'STOP'.
            
        Examples
        --------
        Here's an example of how to use `updateSymbolState`:

        .. code-block:: python
            
            # When `symbol_source` is "SYMBOL_RIC"
            status = client.updateSymbolState(symbol="ESZ3", state="START")
            print(status) # Expected output: True/False
            
            # When `symbol_source` is "SYMBOL_ID"
            status = client.updateSymbolState(symbol=68432, state="STOP")
            print(status) # Expected output: True/False
            
        """
        assert state in ['START', 'STOP'], "state must be either 'START' OR 'STOP'"
        
        indx = self.tradingUniverse.index(symbol)
        
        return self.update_row_state(indx, state)
    
    
    ##
    def getStateSymbol(self, symbol):
        """
        Gets the state of a symbol.

        Parameters
        ----------
        symbol : int | str
            Unique identifier of the symbol.

        Returns
        -------
        int
            0 if the state is 'STOP', 1 if the state is 'START'.
            
        Examples
        --------
        Here's an example of how to use `getStateSymbol`:

        .. code-block:: python
            
            # When `symbol_source` is "SYMBOL_RIC"
            state = client.getStateSymbol(symbol="ESZ3")
            print(state) # Expected output: 'START'/'STOP'
            
            # When `symbol_source` is "SYMBOL_ID"
            state = client.getStateSymbol(symbol=68432)
            print(state) # Expected output: 'START'/'STOP'
        
        """
        
        indx = self.tradingUniverse.index(symbol)    
        return self.get_state_row(indx)
    

    ##
    def getInstrumentStatus(self, symbol):
        """
        Get the status of an instrument.
        
        Parameters
        ----------
        symbol : int | str
            Unique identifier of the symbol.
            
        Raises
        ------
        TimeoutError
            If the response is not received within the timeout period.

        Returns
        -------
        dict | None
            - 'timestamp': datetime.datetime
            - 'response_status': 'SUCCESS' | 'FAILURE'
            - 'status': For detailed information on possible values, see :ref:`variable_documentation`.

        Examples
        --------
        Here's an example of how to use `getInstrumentStatus`:
        
        .. code-block:: python
            
            # When `symbol_source` is "SYMBOL_RIC"
            state = client.getInstrumentStatus(symbol="ESZ3")
            
            # When `symbol_source` is "SYMBOL_ID"
            state = client.getInstrumentStatus(symbol=68432)

        """
        
        #
        dt_ = dt.datetime.utcnow()
        st_time = time.time()
        
        self.request_instrument_status(symbol)
        
        while True:
            status_dict = self.get_instrument_status(symbol)
            if status_dict is not None and status_dict['timestamp'] >= dt_:
                return status_dict
            
            #
            if time.time() - st_time > self.config.response_timeout:
                raise TimeoutError(f"Response was not received. More than {self.config.response_timeout} seconds have passed.")
                
            time.sleep(0.01)

    def getBidAskSnapshot(self, symbol):
        """
        Get the bid ask snapshot of an instrument.
        
        Parameters
        ----------
        symbol : int | str
            Unique identifier of the symbol.
        
        Raises
        ------
        TimeoutError
            If the response is not received within the timeout period.
        
        Returns
        -------
        dict | None
            - 'timestamp': datetime.datetime
            - 'bid': SortedDict
            - 'ask': SortedDict
        
        Examples
        --------
        Here's an example of how to use `getBidAskSnapshot`:

        .. code-block:: python
            
            # When `symbol_source` is "SYMBOL_RIC"
            state = client.getBidAskSnapshot(symbol="ESZ3")
            
            # When `symbol_source` is "SYMBOL_ID"
            state = client.getBidAskSnapshot(symbol=68432)
        
        """
        
        self.request_bid_ask_snapshot(symbol)

        curr_ts = dt.datetime.utcnow()        
        st_time = time.time()
        while True:            
            #
            last_update = self.BID_DICT.get('LAST_UPDATE', None)
            
            if last_update is not None and last_update > curr_ts:
                ask_dict = {x: self.ASK_DICT[symbol][x] for x in self.ASK_DICT[symbol].__reversed__()}
                return {'timestamp': last_update, 'bid': self.BID_DICT[symbol], 'ask': ask_dict}
            
            if time.time() - st_time > self.config.response_timeout:
                raise TimeoutError(f"Response was not received. More than {self.config.response_timeout} seconds have passed.")
            
    
