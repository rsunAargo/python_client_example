
import zmq
import signal
import sys
import time
from queue import Queue
import traceback
from typing import Dict, TypedDict
import psycopg2
import psycopg2.extras as psycopg2_e
from abc import ABC, abstractmethod

from pythonclient.utils import timeout, event_monitoring, get_symbol_map_dict
from pythonclient.config_read import ConfigObjectClass


from pythonclient.marketDataServerClient import MarketDataServerClient
from pythonclient.tradingServerClient import TradeServerClient
from pythonclient.GUIServerClient import GUIServerClient

class TradingClientBase(MarketDataServerClient, TradeServerClient, GUIServerClient):
    """
    A base class for trading clients, integrating functionalities from market data, trading, and GUI server clients.

    Attributes
    ----------
    config : ConfigObjectClass
        Configuration object containing various settings.
    SEND_QUEUE : Queue
        Queue for sending messages.
    CONN : connection
        Database connection object.
    CURSOR : cursor
        Database cursor for executing queries.
    SYMBOL_ID_MAPPING : dict
        Mapping from symbol names to symbol IDs.
    SYMBOL_EXCHANGE_MAPPING : dict
        Mapping from symbol names to their respective exchanges.
    SYMBOL_NAME_MAPPING : dict
        Mapping from symbol IDs to symbol names.

    Methods
    -------
    __init__(self, config_path: str, trading_universe: list, symbol_source: str)
        Initializes the TradingClientBase instance.
    __request_open_orders(self)
        Requests all open orders from the trading server for all exchanges.
    __checks_trading_universe(self, trading_universe: list, symbol_source: str)
        Validates the trading universe and symbol source.
    connect_postgre(self)
        Connects to the PostgreSQL database specified in the configuration.
    shutdown(self, signum, frame)
        Handles shutdown procedure and exits the program when SIGINT is received.
    subscribe_data(self, symbol_id_ls)
        Subscribes to data based on the provided symbol ID list.
    register_poller(self)
        Registers sockets with the ZMQ Poller for event polling.
    send_msg(self)
        Sends messages from the send queue.
    recv_msg(self)
        Receives messages from registered sockets.
    run(self)
        Processes and sends messages from the send queue.
    """

    def __init__(self, config_path: str, trading_universe: list, symbol_source: str):
        """
        Initializes the TradingClientBase instance and prepares all required sockets and also initializes trading symbols.
        """

        ## Init all the clients
        super().__init__(config_path)
                
        self.config = ConfigObjectClass(config_path)
        
        self.__checks_trading_universe(trading_universe, symbol_source)

        ### Keeping track of all the sockets
        
        self.SEND_QUEUE = Queue()
        self.KEEP_RUNNING = True

        self.CONN, self.CURSOR = self.connect_postgre()
        
        signal.signal(signal.SIGINT, self.shutdown)
        signal.signal(signal.SIGTERM, self.shutdown)

        self.SYMBOL_ID_MAPPING, self.SYMBOL_EXCHANGE_MAPPING = get_symbol_map_dict(trading_universe, symbol_source, self.CURSOR) # key: symbol_name, value: symbol_id
        self.SYMBOL_NAME_MAPPING = {v: k for k, v in self.SYMBOL_ID_MAPPING.items()} # key: symbol_id, value: symbol_name 
        
        ## Prepare sockets
        self.register_poller()
        
        ## Init trading symbols
        self.init_symbols(trading_universe)

    def __checks_trading_universe(self, trading_universe: list, symbol_source: str):
        """
        Validates the trading universe and symbol source.
        
        Ensures that the trading universe does not contain duplicates, is not empty, and the symbol source is valid.
        
        Parameters
        ----------
        trading_universe : list
            List of symbol IDs.
        symbol_source : str
            Source of the symbols, one of "SYMBOL_RIC", "SYMBOL_ID", "BLOOMBERG_CODE".

        Raises
        ------
        AssertionError
            If `symbol_source` is not valid or `trading_universe` contains duplicates or is empty.
        """
        
        assert symbol_source in ["SYMBOL_RIC", "SYMBOL_ID", "BLOOMBERG_CODE"], "symbol_source must be either SYMBOL_RIC, SYMBOL_ID, BLOOMBERG_CODE"        
        assert len(set(trading_universe)) == len(trading_universe), "trading_universe must not contain duplicates"
        assert len(trading_universe) > 0, "trading_universe must not be empty"


    def connect_postgre(self):
        """
        Connects to the PostgreSQL database specified in the configuration.

        Returns
        -------
        tuple
            A tuple containing the connection and cursor objects for the database.
        """
        
        conn = psycopg2.connect(
                    user=self.config.db_config['USER'],
                    password=self.config.db_config['PASSWORD'],
                    host=self.config.db_config['HOST'],
                    port=self.config.db_config['PORT'],
                    database=self.config.db_config['DATABASE']
                    )

        ##
        cursor = conn.cursor(cursor_factory=psycopg2_e.RealDictCursor)

        ##
        return conn, cursor
            
        
    def shutdown(self, signum=None, frame=None):
        """
        Handles shutdown procedure and exits the program.

        This method is triggered when a SIGINT signal is received (e.g., Ctrl+C). It safely logs out from various servers,
        closes connections, and exits the program.

        Parameters
        ----------
        signum : int
            Signal number.
        frame : Frame
            Frame object.
        """
       
        self.config.masterlog.critical("Logging out. CTRL + C was pressed")

        # GUI LOG OUT
        self.gui_logout()

        ## log out TS
        for key in self.TS_DEALER_DICT.keys():
            self.tradeserver_logout(socket=self.TS_DEALER_DICT[key])
            
        # log out MD
        for key in self.MD_DEALER_DICT.keys():
            self.marketdata_logout(dealer_socket=self.MD_DEALER_DICT[key], sub_socket=self.MD_SUB_DICT[key])
        

        if hasattr(self, 'ZMQ_CONTEXT'):
            self.ZMQ_CONTEXT.destroy()
        
        #
        self.KEEP_RUNNING = False
        if signum:
            sys.exit()
        
        else:
            self.config.masterlog.critical("Please press CTRL + C again to exit the program")


    def subscribe_data(self, symbol_id_ls):
        """
        Subscribes to data based on the provided symbol ID list.

        Parameters
        ----------
        symbol_id_ls : list
            List of symbol IDs to subscribe or unsubscribe.

        Raises
        ------
        ValueError
            If `symbol_id_ls` is empty.
        
        AssertionError
            If `symbol_id_ls` is not a list.
        """

        assert isinstance(symbol_id_ls, list), "symbol_id_ls must be a list"
        
        if len(symbol_id_ls) == 0:
            raise ValueError("symbol_id_ls is empty")

        for sym in symbol_id_ls:
            sym_id = self.SYMBOL_ID_MAPPING[sym]
            hexTopic = hex(sym_id)[2:]
            exchange = self.SYMBOL_EXCHANGE_MAPPING[sym]
            region = self.config.md_exchange_region_mapping[exchange]
            socket = self.MD_SUB_DICT[region]
            socket.setsockopt(zmq.SUBSCRIBE, hexTopic.encode('utf-8'))
            self.config.masterlog.info(f"Subscribing to {sym_id}")
    

    def register_poller(self):
        """
        Registers all relevant sockets with the ZMQ Poller.

        This method is used to set up the poller for receiving messages from various sockets that the client interacts with.
        """
        self.poller = zmq.Poller()
        for socket in self.ALL_SOCKET_LIST:
            self.poller.register(socket, zmq.POLLIN)

    
    def send_msg(self):
        """
        Sends a message to the server.
        """
        while not self.SEND_QUEUE.empty():
            socket, buf = self.SEND_QUEUE.get()
            socket.send(buf)

    def recv_msg(self):
        """
        Receives a message from the server.

        Parameters
        ----------
        socket : zmq.Socket
            Socket to receive message from.

        Returns
        -------
        bytes
            Received message.
        """
        socks = dict(self.poller.poll(timeout=0))
        
        for socket, status in socks.items():
            if status == zmq.POLLIN:
                
                socket_name = self.SOCKET_INFO_DICT[socket.underlying]['name']
                socket_type = self.SOCKET_INFO_DICT[socket.underlying]['type']
                self.config.masterlog.debug(f"Received message from socket: {socket_name}")
                
                callback = self.ZMQ_CALLBACK_DICT[socket]
                
                if socket_type in ["monitor"]:
                    callback(socket, self.config)
                elif socket_name == 'gui_server_dealer_socket':
                    callback()
                else:
                    callback(socket)


    ##
    def run(self):
        '''
        This is the main loop of the client. It keeps running until the user presses Ctrl-C or `shutdown` is called
        
        It will block the main thread.
        '''
        
        while self.KEEP_RUNNING: # Keep running until the user presses Ctrl-C or `shutdown` is called            
            self.recv_msg() # Receive messages from the server
            self.send_msg() # Send messages to the server
