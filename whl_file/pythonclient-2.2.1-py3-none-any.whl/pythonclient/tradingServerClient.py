
import flatbuffers
from abc import ABC, abstractmethod
import datetime as dt
from typing import TypedDict, Dict
from queue import Queue
import zmq

from pythonclient.config_read import ConfigObjectClass
import pythonclient.schema.tradeServer as tradeServer
from pythonclient.zmqBase import ZMQBase
from pythonclient.utils import event_monitoring


class InnerDict(TypedDict):
    last_update: dt.datetime
    quantity: int
    status: bool

class TradeServerClient(ABC, ZMQBase):
    """
    A client class for interacting with a trade server, managing orders, and handling trade-related operations.

    This class includes methods for initializing connections with the trade server, processing trade orders and updates,
    and sending various trade-related requests to the trade server.

    Attributes
    ----------
    ts_config : ConfigObjectClass
        Configuration object containing trade server settings.
    SEND_QUEUE : Queue
        Queue for sending messages to the trade server.
    SYMBOL_ID_MAPPING : dict
        Dictionary mapping symbol names to their respective IDs.
    SYMBOL_EXCHANGE_MAPPING : dict
        Dictionary mapping symbol names to their respective exchanges.
    SYMBOL_NAME_MAPPING : dict
        Dictionary mapping symbol IDs to their names.
    SYMBOL_ID_DICT : dict
        Dictionary holding symbol IDs.
    STRATEGY_STATE_DICT : dict
        Dictionary holding strategy states.

    Methods
    -------
    __init__(self, config_path)
        Initializes the TradeServerClient instance.
    tradeserver_init(self)
        Initializes and sets up the connection with the trade server.
    tradeserver_logout(self, socket)
        Logs out from the trade server and closes the connection.
    handle_tradeserver_data(self, socket)
        Handles updates received from the trade server.
    __process_admin_reply(self, msg)
        Processes an admin reply message received from the trade server.
    on_position_update(self, account_id, strategy_id, client_id, symbol, position, status)
        Abstract method to handle position updates.
    on_pre_acknowledge(self, req_id, uuid)
        Abstract method to handle pre-acknowledged orders.
    on_acknowledge(self, ts, account_id, strategy_id, client_id, symbol, uuid, side, sent_price, sent_size, order_state, is_third_party_manual)
        Abstract method to handle order acknowledgments.
    on_fill(self, ts, account_id, strategy_id, client_id, symbol, uuid, side, sent_price, sent_size, stop_price, exec_price, exec_size, order_state, is_third_party_manual)
        Abstract method to handle order fills.
    on_cancel(self, ts, account_id, strategy_id, client_id, symbol, uuid, sent_price, sent_size, stop_price, remaining_size, order_state, is_third_party_manual)
        Abstract method to handle order cancellations.
    on_reject(self, ts, account_id, strategy_id, client_id, symbol, uuid, sent_price, stop_price, order_state, rejection_reason, is_third_party_manual)
        Abstract method to handle order rejections.
    on_order_details(self, ts, account_id, strategy_id, client_id, symbol, uuid, side, sent_price, sent_size, stop_price, order_state, exec_price, exec_size, price_type, time_in_force)
        Abstract method to handle detailed order information.
    __extract_order_details(self, msg, extract_ls)
        Extracts order details from a message.
    __process_trade_reply(self, msg)
        Processes trade reply messages from the trade server.
    tradeserver_login(self, socket)
        Logs into the trade server.
    __exchange_check(self, exchange)
        Validates the exchange name.
    __place_order_checks(self, price_type, time_in_force, exchange, price, stop_price)
        Performs validation checks for order placement.
    place_order(self, symbol, side, size, price_type, time_in_force, req_id, price, stop_price, auto_cancel, is_manual)
        Sends a new order to the trade server.
    query_order(self, req_id, uuid, exchange, is_manual)
        Queries the status of a specific order.
    cancel_order(self, req_id, uuid, exchange, is_manual)
        Sends a cancellation request for a specific order.
    modify_order(self, uuid, side, price, size, time_in_force, is_manual)
        Sends a request to modify an existing order.
    query_position_clientid(self, symbol)
        Queries the position details for a specific symbol based on client ID.
    query_position_accountid(self, symbol)
        Queries the position details for a specific symbol based on account ID.
    cancel_all_orders(self, req_id, exchange, is_manual)
        Requests cancellation of all active orders for a specific exchange.
    query_all_active_orders(self, req_id, exchange, isManual)
        Queries details of all active orders for a specific exchange.
    """

    def __init__(self, config_path):
        """
        Initializes the TradeServerClient instance.

        Sets up the configuration from the provided path, initializes trade server communication sockets,
        and prepares dictionaries for symbol and order mappings.

        Parameters
        ----------
        config_path : str
            Path to the configuration file used for setting up the trade server connection.
        """

        super().__init__(config_path)
        
        self.ts_config = ConfigObjectClass(config_path)
        self.tradeserver_init()
        
        self.__rejection_code_mapping = {y:x for x,y in tradeServer.RejectionCode.__dict__.items() if not x.startswith('__')}
        self.__side_mapping = {y:x for x,y in tradeServer.Side.__dict__.items() if not x.startswith('__')}
        self.__price_type_mapping = {y:x for x,y in tradeServer.PriceType.__dict__.items() if not x.startswith('__')}
        self.__timeInForce_mapping = {y:x for x,y in tradeServer.TimeInForce.__dict__.items() if not x.startswith('__')}
        self.__order_state_mapping = {y:x for x,y in tradeServer.OrderState.__dict__.items() if not x.startswith('__')}


        ##
        self.SEND_QUEUE: Queue = Queue()
        self.SYMBOL_ID_MAPPING = dict()
        self.SYMBOL_EXCHANGE_MAPPING = dict()
        self.SYMBOL_NAME_MAPPING = dict()
        self.SYMBOL_ID_DICT = dict()
        self.STRATEGY_STATE_DICT = dict()

    def tradeserver_init(self):
        """
        Loads the configuration and initializes the connection with all the trading server in the config.
        """
        
        ##
        identity = str(self.ts_config.strategy_id).encode('utf-8')
        
        ##
        for region in self.ts_config.region_ip_config.keys():
            
            connect_ts_chk = 0
            if self.ts_config.mode == "PaperTrading" and region == "PAPER":
                connect_ts_chk = 1
                
            elif self.ts_config.mode == "Live" and region != "PAPER":
                connect_ts_chk = 1
                
            
            # TS CREATE SOCKET
            if connect_ts_chk == 1:
                ##
                self.ts_config.masterlog.info(f"Connecting to trading server request socket for {region}")

                self.TS_DEALER_DICT[region] = self.ZMQ_CONTEXT.socket(zmq.DEALER)
                self.TS_DEALER_DICT[region].setsockopt(zmq.IDENTITY, identity)
                self.TS_DEALER_DICT[region].setsockopt(zmq.HEARTBEAT_IVL, int(self.ts_config.hearbeat_interval*1000))
                self.TS_DEALER_DICT[region].setsockopt(zmq.HEARTBEAT_TIMEOUT, int(self.ts_config.heartbeat_timeout*1000))
                
                self.TS_DEALER_DICT[region].RCVTIMEO = int(self.ts_config.connection_timeout * 1000)
                self.ts_config.masterlog.info("Connecting to trading server request socket")
                self.TS_DEALER_DICT[region].connect(self.ts_config.region_ip_config[region]['TRADING_SERVER_ROUTER'])

                # TS MONITOR SOCKET
                monitor_socket = self.TS_DEALER_DICT[region].get_monitor_socket()
                
                # TS LOG IN
                self.tradeserver_login(socket=self.TS_DEALER_DICT[region])
                
                # TS REGISTER CALLBACKS
                self.ZMQ_CALLBACK_DICT[self.TS_DEALER_DICT[region]] = self.handle_tradeserver_data
                self.ZMQ_CALLBACK_DICT[monitor_socket] = event_monitoring
                
                ##
                self.ALL_SOCKET_LIST.append(self.TS_DEALER_DICT[region])
                self.ALL_SOCKET_LIST.append(monitor_socket)
                
                # TS SOCKET INFO
                self.SOCKET_INFO_DICT[self.TS_DEALER_DICT[region].underlying] = {'name': 'trading_server_dealer_socket', "type": "trading_server", "region": region}
                self.SOCKET_INFO_DICT[monitor_socket.underlying] = {'name': 'trading_server_monitor_socket', "type": "monitor", "region": region}

            ## NO MD FOR PAPER
            if region == "PAPER":
                continue
        
        
    def tradeserver_logout(self, socket: zmq.Socket):
        """
        Logs out from the trading server and closes the socket connection.

        Sends a logout request to the trading server and closes the connection based on the reply. 
        The state of the socket connection is updated accordingly.

        Parameters
        ----------
        socket : zmq.Socket
            The ZeroMQ socket instance used for communication with the trading server.
        """

        builder = flatbuffers.Builder(2048)
        
        tradeServer.LogOutRequestMessageStart(builder)
        tradeServer.LogOutRequestMessageAddClientId(builder, self.ts_config.client_id)
        tradeServer.LogOutRequestMessageAddStrategyId(builder, self.ts_config.strategy_id)
        log_out_request_message = tradeServer.LogOutRequestMessageEnd(builder)

        # AdminRequestUnion
        logout_admin_union = tradeServer.AdminRequestUnion.logOutRequestMessage
        tradeServer.AdminRequestMessageStart(builder)
        tradeServer.AdminRequestMessageAddAdminRequestUnionType(builder, logout_admin_union)
        tradeServer.AdminRequestMessageAddAdminRequestUnion(builder, log_out_request_message)
        admin_request_message = tradeServer.AdminRequestMessageEnd(builder)

        message_request_union = tradeServer.MessageRequestUnion.adminRequestMessage
        tradeServer.TradeServerRequestMessageStart(builder)
        tradeServer.TradeServerRequestMessageAddMessageRequestUnionType(builder, message_request_union)
        tradeServer.TradeServerRequestMessageAddMessageRequestUnion(builder, admin_request_message)
        trade_server_request_message = tradeServer.TradeServerRequestMessageEnd(builder)

        builder.Finish(trade_server_request_message)
        buf = builder.Output()

        self.ts_config.masterlog.info("Sending logout request to trading server")
        socket.send(buf)

        recv_buf = socket.recv()
        self.ts_config.masterlog.info("Received logout reply from trading server")

        #####
        logout_server_reply = tradeServer.TradeServerReplyMessage.GetRootAs(recv_buf, 0)

        ## 
        admin_reply = tradeServer.AdminReplyMessage()
        admin_reply.Init(logout_server_reply.MessageReplyUnion().Bytes, logout_server_reply.MessageReplyUnion().Pos)
        
        ####
        logout_reply = tradeServer.LogOutReplyMessage()
        logout_reply.Init(admin_reply.AdminReplyUnion().Bytes, admin_reply.AdminReplyUnion().Pos)

        ####
        if logout_reply.LogOutStatus() == tradeServer.LogOutStatus.SUCCESS:
            self.ts_config.masterlog.info(f"TradeServer Logout reply. Client: {logout_reply.ClientId()} STATUS: SUCCESS")
            socket.close()
        
        else:
            self.ts_config.masterlog.info(f"TradeServer Logout reply. Client: {logout_reply.ClientId()} STATUS: FAILURE")

    ##
    def handle_tradeserver_data(self, socket: zmq.Socket):
        """
        Handles updates received from a trading server.

        This method waits for a message from the trading server, parses it, and then processes it based on its type. 
        There are two types of messages that can be processed: `trade reply` messages and `admin reply` messages. 
        Each type is handled by a dedicated method. If the message type is unsupported, the method logs a critical error and raises a ValueError.

        Parameters
        ----------
        socket : zmq.Socket
            The ZeroMQ socket instance used for communication with the trading server.

        Raises
        ------
        ValueError
            If the received message type from the trading server is unsupported, a ValueError is raised to indicate this issue.

        """
        
        msg = socket.recv()
        msg = tradeServer.TradeServerReplyMessage.GetRootAs(msg, 0)
        
        if msg.MessageReplyUnionType() == tradeServer.MessageReplyUnion.tradeReplyMessage:
            self.__process_trade_reply(msg)
        
        elif msg.MessageReplyUnionType() == tradeServer.MessageReplyUnion.adminReplyMessage:
            self.__process_admin_reply(msg)
        
        else:
            self.ts_config.masterlog.critical("MessageReplyUnionType not supported")
            raise ValueError("MessageReplyUnionType not supported")
    
    
    def __process_admin_reply(self, msg: tradeServer.TradeServerReplyMessage):
        """
        Processes an admin reply message received from the trade server.

        This method decodes the admin reply message and determines its type. 
        If the type is a query position reply message, it further processes this message to extract position details, status, and symbol ID. These details are then logged and stored in a dictionary. 
        If the admin reply type is unsupported, a critical log is recorded, and a ValueError is raised.

        Parameters
        ----------
        msg : tradeServer.TradeServerReplyMessage
            The message received from the trade server, which needs to be processed.

        Raises
        ------
        ValueError
            If the admin reply message type is unsupported, a ValueError is raised.

        Notes
        -----
        - This method assumes the existence of a global or class-level dictionary `__POSITION_DICT` to store the processed data.
        """

        adminReplyMessage = tradeServer.AdminReplyMessage()
        adminReplyMessage.Init(msg.MessageReplyUnion().Bytes, msg.MessageReplyUnion().Pos)
        
        if adminReplyMessage.AdminReplyUnionType() == tradeServer.AdminReplyUnion.queryPositionReplyMessage:            
            ##
            queryPositionReplyMessage = tradeServer.QueryPositionReplyMessage()
            queryPositionReplyMessage.Init(adminReplyMessage.AdminReplyUnion().Bytes, adminReplyMessage.AdminReplyUnion().Pos)
            
            account_id = queryPositionReplyMessage.AccountId()
            strategy_id = queryPositionReplyMessage.StrategyId()
            client_id = queryPositionReplyMessage.ClientId()
            symbol = self.SYMBOL_NAME_MAPPING[queryPositionReplyMessage.SymbolId()]
            position = queryPositionReplyMessage.Position()
            status = queryPositionReplyMessage.Status()
            status = "SUCCESS" if status == tradeServer.QueryPositionStatus.SUCCESS else "FAILURE"

            self.ts_config.masterlog.debug(f"Query Position Reply. Symbol: {symbol} Position: {position} Status: {status}")
            
            ##
            self.on_position_update(account_id=account_id, strategy_id=strategy_id, client_id=client_id, symbol=symbol, position=position, status=status)
        
        else:
            self.ts_config.masterlog.critical("AdminReplyUnionType not supported")
            raise ValueError("AdminReplyUnionType not supported")
        

    def get_state_symbol(self, symbol):

        row_indx = self.SYMBOL_ID_DICT.get(str(symbol), None)
        
        if row_indx is None:
            raise Exception("Symbol ID not found")
        
        return self.STRATEGY_STATE_DICT.get(row_indx, None)
        
    ##
    @abstractmethod
    def on_position_update(self, account_id, strategy_id, client_id, symbol, position, status):
        """
        Handles position updates from the trade server.

        This is an abstract method that should be implemented by the user in a subclass.

        Parameters
        ----------
        account_id : int
            The account ID associated with the position.
        strategy_id : int
            The strategy ID associated with the position.
        client_id : int
            The client ID associated with the position.
        symbol : str or int
            The symbol associated with the position.
        position : float
            The current position quantity.
        status : str
            The status of the position update.
        """
        pass
    
    @abstractmethod
    def on_pre_acknowledge(self, req_id, uuid):
        """
        Processes pre-acknowledgment of an order from the trade server.

        This is an abstract method that should be implemented in a subclass.

        Parameters
        ----------
        req_id : int
            The request ID associated with the request.
        uuid : int
            The UUID of the request.
        """
        pass

    @abstractmethod
    def on_acknowledge(self, ts, account_id, strategy_id, client_id, symbol, uuid, side, sent_price, sent_size, order_state, is_third_party_manual):
        """
        Processes order acknowledgment from the trade server.

        This is an abstract method that should be implemented in a subclass by the user.

        Parameters
        ----------
        ts : utc datetime
            Timestamp of the acknowledgment.
        account_id : int
            The account ID associated with the order.
        strategy_id : int
            The strategy ID associated with the order.
        client_id : int
            The client ID associated with the order.
        symbol : str or int
            The trading symbol of the order.
        uuid : int
            The UUID of the order.
        side : str
            The side of the order ('BUY' or 'SELL').
        sent_price : float
            The price at which the order was placed.
        sent_size : float
            The size of the order.
        order_state : str
            The current state of the order. For detailed information on possible values, see :ref:`variable_documentation`.
        is_third_party_manual : bool
            Indicates if the order was manually placed by a third party.
        """
        pass
    
    
    @abstractmethod
    def on_fill(self, ts, account_id, strategy_id, client_id, symbol, uuid, side, sent_price, sent_size, stop_price, exec_price, exec_size, order_state, is_third_party_manual):
        """
        Handles order fill updates from the trade server.

        This is an abstract method that should be implemented in a subclass by the user. 

        Parameters
        ----------
        ts : utc datetime
            Timestamp of the fill.
        account_id : int
            The account ID associated with the order.
        strategy_id : int
            The strategy ID associated with the order.
        client_id : int
            The client ID associated with the order.
        symbol : str or int
            The trading symbol of the order.
        uuid : int
            The UUID of the order.
        side : str
            The side of the order ('BUY' or 'SELL').
        sent_price : float
            The price at which the order was placed.
        sent_size : float
            The size of the order.
        stop_price : float
            The stop price of the order, if applicable.
        exec_price : float
            The execution price of the order.
        exec_size : float
            The executed size of the order.
        order_state : str
            The current state of the order. For detailed information on possible values, see :ref:`variable_documentation`.
        is_third_party_manual : bool
            Indicates if the order was manually placed by a third party.
        """
        pass
    
    @abstractmethod
    def on_cancel(self, ts, account_id, strategy_id, client_id, symbol, uuid, sent_price, sent_size, stop_price, remaining_size, order_state, is_third_party_manual):
        """
        Processes order cancellation updates from the trade server.

        This is an abstract method that should be implemented in a subclass by the user.

        Parameters
        ----------
        ts : UTC datetime
            Timestamp of the cancellation.
        account_id : int
            The account ID associated with the order.
        strategy_id : int
            The strategy ID associated with the order.
        client_id : int
            The client ID associated with the order.
        symbol : str or int
            The trading symbol of the order.
        uuid : int
            The UUID of the order.
        sent_price : float
            The price at which the order was placed.
        sent_size : float
            The size of the order.
        stop_price : float
            The stop price of the order, if applicable.
        remaining_size : float
            The remaining size of the order after cancellation.
        order_state : str
            The current state of the order. For detailed information on possible values, see :ref:`variable_documentation`.
        is_third_party_manual : bool
            Indicates if the order was manually placed by a third party.
        """
        pass
    
    @abstractmethod
    def on_reject(self, ts, account_id, strategy_id, client_id, symbol, uuid, sent_price, stop_price, order_state, rejection_code, rejection_reason, is_third_party_manual):
        """
        Handles order rejection notifications from the trade server.

        This is an abstract method that should be implemented in a subclass by the user.

        Parameters
        ----------
        ts : utc datetime
            Timestamp of the rejection.
        account_id : int
            The account ID associated with the order.
        strategy_id : int
            The strategy ID associated with the order.
        client_id : int
            The client ID associated with the order.
        symbol : str or int
            The trading symbol of the order.
        uuid : int
            The UUID of the order.
        sent_price : float
            The price at which the order was placed.
        stop_price : float
            The stop price of the order, if applicable.
        order_state : str
            The current state of the order. For detailed information on possible values, see :ref:`variable_documentation`.
        rejection_code: int
            The rejection code for the order.
        rejection_reason : str
            The reason for order rejection.
        is_third_party_manual : bool
            Indicates if the order was manually placed by a third party.
        """
        pass
    
    @abstractmethod
    def on_order_details(self, ts, account_id, strategy_id, client_id, symbol, uuid, side, sent_price, sent_size, stop_price, order_state, exec_price, exec_size, price_type, time_in_force):
        """
        Receives detailed information about a specific order from the trade server. Usually called in response to a query order request.

        This is an abstract method that should be implemented in a subclass.

        Parameters
        ----------
        ts : utc datetime
            Timestamp of the order detail.
        account_id : int
            The account ID associated with the order.
        strategy_id : int
            The strategy ID associated with the order.
        client_id : int
            The client ID associated with the order.
        symbol : str or int
            The trading symbol of the order.
        uuid : int
            The UUID of the order.
        side : str
            The side of the order ('BUY' or 'SELL').
        sent_price : float
            The price at which the order was placed.
        sent_size : float
            The size of the order.
        stop_price : float
            The stop price of the order, if applicable.
        order_state : str
            The current state of the order. For detailed information on possible values, see :ref:`variable_documentation`.
        exec_price : float
            The execution price of the order.
        exec_size : float
            The executed size of the order.
        price_type : str
            The type of the order price. For detailed information on possible values, see :ref:`variable_documentation`.
        time_in_force : str
            The time-in-force policy of the order. For detailed information on possible values, see :ref:`variable_documentation`.
        """
        pass
    
    def __extract_order_details(self, msg: tradeServer.Acknowledged, extract_ls):
        """
        Extracts specific details from an Flatbuffer order message.

        Parameters
        ----------
        msg : 
            The order message from which details are to be extracted.
        extract_ls : list
            List of attributes to extract from the order message.

        Returns
        -------
        ts : datetime
            Timestamp of the order.
        return_dict : dict
            Dictionary containing extracted order details.
        """
        
        return_dict = {}
        for key in extract_ls:
            return_dict[key] = getattr(msg, key)()
        
        ts_ns = msg.Timestamp()
        ts = dt.datetime.fromtimestamp(ts_ns // 1000000000)
        
        return ts, return_dict

    def __process_trade_reply(self, msg: tradeServer.TradeServerReplyMessage):
        """
        Handles updates received from the trading server regarding order status.
        For example, when an order is filled,acked,etc.., the trading server will send a message
    
        Notes
        -----
        Parses incoming messages from the trading server and updates the respective Order objects
        in the `__ORDER_DICT` attribute.
        """
                
        tradeReply = tradeServer.TradeReplyMessage()
        tradeReply.Init(msg.MessageReplyUnion().Bytes, msg.MessageReplyUnion().Pos)

        if tradeReply.TradeReplyUnionType() == tradeServer.TradeReplyUnion.preAcknowledged:
            repl = tradeServer.PreAcknowledged()
            repl.Init(tradeReply.TradeReplyUnion().Bytes, tradeReply.TradeReplyUnion().Pos)
            
            req_id = repl.ClientReqId()
            uuid = repl.UuId()
                        
            self.ts_config.masterlog.info('Received unacked for orderId: {}'.format(req_id))
            self.ts_config.masterlog.info('Received unacked for UUID: {}'.format(uuid))
            
            self.on_pre_acknowledge(req_id, uuid)    

            
        elif tradeReply.TradeReplyUnionType() == tradeServer.TradeReplyUnion.acknowledged:
            repl = tradeServer.Acknowledged()
            repl.Init(tradeReply.TradeReplyUnion().Bytes, tradeReply.TradeReplyUnion().Pos)
            
            key_ls = ['StrategyId', 'UuId', 'OrderState', 'SymbolId', 'ClientId', 'AccountId', 'IsThirdPartyManual', 'Side', 'SentPrice', 'SentSize']
            ts, value_dict = self.__extract_order_details(repl, extract_ls=key_ls)
            value_dict['OrderState'] = self.__order_state_mapping[value_dict['OrderState']]
            value_dict['Symbol'] = self.SYMBOL_NAME_MAPPING[value_dict.pop('SymbolId')]
            value_dict['Side'] = self.__side_mapping[value_dict['Side']]
                        
            ##
            self.on_acknowledge(ts=ts, account_id=value_dict['AccountId'], strategy_id=value_dict['StrategyId'], client_id=value_dict['ClientId'], symbol=value_dict['Symbol'], uuid=value_dict['UuId'], side=value_dict['Side'], \
                    sent_price=value_dict['SentPrice'], sent_size=value_dict['SentSize'], order_state=value_dict['OrderState'], is_third_party_manual=value_dict['IsThirdPartyManual'])

        elif (tradeReply.TradeReplyUnionType() == tradeServer.TradeReplyUnion.filled) or (tradeReply.TradeReplyUnionType() == tradeServer.TradeReplyUnion.partiallyFilled):
            
            repl = tradeServer.Filled()
            repl.Init(tradeReply.TradeReplyUnion().Bytes, tradeReply.TradeReplyUnion().Pos)

            #
            key_ls = ['StrategyId', 'UuId', 'OrderState', 'SymbolId', 'ClientId', 'AccountId', 'IsThirdPartyManual', 'SentPrice', 'SentSize', "Side", "ExecutedPrice", "ExecutedSize", "SentStopPrice"]
            ts, value_dict = self.__extract_order_details(repl, extract_ls=key_ls)
            value_dict['OrderState'] = self.__order_state_mapping[value_dict['OrderState']]
            value_dict['Symbol'] = self.SYMBOL_NAME_MAPPING[value_dict.pop('SymbolId')] 
            value_dict['Side'] = self.__side_mapping[value_dict['Side']]
            
            ##
            self.on_fill(ts=ts, account_id=value_dict['AccountId'], strategy_id=value_dict['StrategyId'], client_id=value_dict['ClientId'], symbol=value_dict['Symbol'], uuid=value_dict['UuId'], side=value_dict['Side'], \
                    sent_price=value_dict['SentPrice'], sent_size=value_dict['SentSize'], stop_price=value_dict['SentStopPrice'], exec_price=value_dict['ExecutedPrice'], exec_size=value_dict['ExecutedSize'], \
                    order_state=value_dict['OrderState'], is_third_party_manual=value_dict['IsThirdPartyManual'])
            
            
        elif tradeReply.TradeReplyUnionType() == tradeServer.TradeReplyUnion.cancelled:

            repl = tradeServer.Cancelled()
            repl.Init(tradeReply.TradeReplyUnion().Bytes, tradeReply.TradeReplyUnion().Pos)
            
            #
            key_ls = ['StrategyId', 'UuId', "RemainingSize", 'SentSize', 'OrderState', 'SymbolId', 'ClientId', 'AccountId', 'IsThirdPartyManual', "SentStopPrice", "SentPrice"]
            ts, value_dict = self.__extract_order_details(repl, extract_ls=key_ls)
            value_dict['OrderState'] = self.__order_state_mapping[value_dict['OrderState']]
            value_dict['Symbol'] = self.SYMBOL_NAME_MAPPING[value_dict.pop('SymbolId')] 
            
            ##            
            self.on_cancel(ts=ts, account_id=value_dict['AccountId'], strategy_id=value_dict['StrategyId'], client_id=value_dict['ClientId'], symbol=value_dict['Symbol'], uuid=value_dict['UuId'], \
                    sent_price=value_dict['SentPrice'], sent_size=value_dict['SentSize'], stop_price=value_dict['SentStopPrice'], remaining_size=value_dict['RemainingSize'], order_state=value_dict['OrderState'], is_third_party_manual=value_dict['IsThirdPartyManual'])

        elif tradeReply.TradeReplyUnionType() == tradeServer.TradeReplyUnion.rejected:
            
            repl = tradeServer.Rejected()
            repl.Init(tradeReply.TradeReplyUnion().Bytes, tradeReply.TradeReplyUnion().Pos)
            
            ##
            key_ls = ['StrategyId', 'UuId', 'OrderState', 'SymbolId', 'ClientId', 'AccountId', 'IsThirdPartyManual', "SentPrice", "SentStopPrice", "RejectionCode"]
            ts, value_dict = self.__extract_order_details(repl, extract_ls=key_ls)
            value_dict['OrderState'] = self.__order_state_mapping[value_dict['OrderState']]
            value_dict['RejectionReason'] = self.__rejection_code_mapping[value_dict['RejectionCode']]

            if value_dict['SymbolId'] in self.SYMBOL_NAME_MAPPING:
                value_dict['Symbol'] = self.SYMBOL_NAME_MAPPING[value_dict.pop('SymbolId')]
            
            else:
                value_dict['Symbol'] = None

            self.ts_config.masterlog.warning("Rejection Reason: {}".format(value_dict['RejectionReason']))

            ##
            self.on_reject(ts=ts, account_id=value_dict['AccountId'], strategy_id=value_dict['StrategyId'], client_id=value_dict['ClientId'], symbol=value_dict['Symbol'], uuid=value_dict['UuId'], \
                    sent_price=value_dict['SentPrice'], stop_price=value_dict['SentStopPrice'], order_state=value_dict['OrderState'], rejection_code=value_dict['RejectionCode'], rejection_reason=value_dict['RejectionReason'], is_third_party_manual=value_dict['IsThirdPartyManual'])

        
        elif tradeReply.TradeReplyUnionType() == tradeServer.TradeReplyUnion.orderStatus:
            
            repl = tradeServer.OrderStatus()
            repl.Init(tradeReply.TradeReplyUnion().Bytes, tradeReply.TradeReplyUnion().Pos)
            
            ##
            key_ls = ['StrategyId', 'UuId', 'ExecutedPrice', 'ExecutedSize', 'SentSize', 'SentPrice', 'OrderState', 'SymbolId', 'ClientId', 'AccountId', "SentStopPrice", \
                    "Side", "PriceType", "TimeInForce"]
            
            ##
            ts, value_dict = self.__extract_order_details(repl, extract_ls=key_ls)
            
            value_dict['OrderState'] = self.__order_state_mapping[value_dict['OrderState']]
            value_dict['Symbol'] = self.SYMBOL_NAME_MAPPING[value_dict.pop('SymbolId')]
            value_dict['Side'] = self.__side_mapping[value_dict['Side']]
            value_dict['PriceType'] = self.__price_type_mapping[value_dict['PriceType']]
            value_dict['time_in_force'] = self.__timeInForce_mapping[value_dict['TimeInForce']]
            
            ##
            self.on_order_details(ts=ts, account_id=value_dict['AccountId'], strategy_id=value_dict['StrategyId'], client_id=value_dict['ClientId'], symbol=value_dict['Symbol'], uuid=value_dict['UuId'], \
                    side=value_dict['Side'], sent_price=value_dict['SentPrice'], sent_size=value_dict['SentSize'], stop_price=value_dict['SentStopPrice'], order_state=value_dict['OrderState'], \
                    exec_price=value_dict['ExecutedPrice'], exec_size=value_dict['ExecutedSize'], price_type=value_dict['PriceType'], time_in_force=value_dict['TimeInForce'])

        else:
            self.ts_config.masterlog.critical(f"TradeReplyUnionType not supported: {tradeReply.TradeReplyUnionType()}")
            raise ValueError("TradeReplyUnionType not supported")
            
            

    def tradeserver_login(self, socket: zmq.Socket):
        """
        Logs into the trading server.

        Sends a login request to the trading server and handles the response, updating 
        the socket state accordingly.

        Parameters
        ----------
        socket : zmq.Socket
            The ZeroMQ socket instance used for communication with the trading server.

        Raises
        ------
        ValueError
            If login to the trading server fails.
        """
        
        builder = flatbuffers.Builder(2048)
        
        tradeServer.LogInRequestMessageStart(builder)
        tradeServer.LogInRequestMessageAddClientId(builder, self.ts_config.client_id)
        tradeServer.LogInRequestMessageAddStrategyId(builder, self.ts_config.strategy_id)
        logInMsg = tradeServer.LogInRequestMessageEnd(builder)
        
        tradeServer.AdminRequestMessageStart(builder)
        tradeServer.AddAdminRequestUnionType(builder, tradeServer.AdminRequestUnion.logInRequestMessage)
        tradeServer.AddAdminRequestUnion(builder, logInMsg)
        adminMsg = tradeServer.AdminRequestMessageEnd(builder)

        tradeServer.TradeServerRequestMessageStart(builder)
        tradeServer.AddMessageRequestUnionType(builder, tradeServer.MessageRequestUnion.adminRequestMessage)
        tradeServer.AddMessageRequestUnion(builder, adminMsg)
        requestMsg = tradeServer.TradeServerRequestMessageEnd(builder)
        builder.Finish(requestMsg)
        buf = builder.Output()

        self.ts_config.masterlog.info("Sending login request to trading server")

        socket.send(buf)
        binBuffer = socket.recv()

        self.ts_config.masterlog.info("Received login reply from trading server")

        m = tradeServer.TradeServerReplyMessage.GetRootAs(binBuffer, 0)
        adminReplyMessage = tradeServer.AdminReplyMessage()
        adminReplyMessage.Init(m.MessageReplyUnion().Bytes, m.MessageReplyUnion().Pos)

        loginReply = tradeServer.LogInReplyMessage()
        loginReply.Init(adminReplyMessage.AdminReplyUnion().Bytes, adminReplyMessage.AdminReplyUnion().Pos)

        success = loginReply.LogInStatus()
        if success == tradeServer.LogInStatus.FAILURE:
            self.ts_config.masterlog.critical("Failed to log in to trading server, please check your strategy id and client id")
            raise ValueError("Failed to log in to trading server, please check your credentials")
        
        else:
            self.ts_config.masterlog.info("Successfully logged in to trading server")

        self.ts_config.masterlog.info("Trade Server Client ID: {}".format(self.ts_config.strategy_id))

    ##
    @staticmethod
    def __exchange_check(exchange):
        """
        Performs validation checks for the exchange name.
        
        Parameters
        ----------
        exchange : str
            The name of the exchange. For detailed information on possible values, see :ref:`variable_documentation`.
        
        Raises
        ------
        AssertionError
            If the exchange name is not supported.
        """
        assert exchange in ["EURONEXT", "EUREX", "JPX", "HKEX", "CME", "ICE_L"], "Exchange name not in ['EURONEXT', 'EUREX', 'JPX', 'HKEX', 'CME', 'ICE_L']"
        
    
    @staticmethod
    def __place_order_checks(price_type, time_in_force, exchange, price=None, stop_price=None):
        
        """
        Performs validation checks for order placement based on the exchange, price type, and time in force.

        This method validates the compatibility of `price_type` and `time_in_force` with the specified `exchange`. 
        It also checks the requirements for `price` and `stop_price` parameters based on the `price_type`. 
        The method asserts conditions to ensure that the parameters are consistent with the requirements of different exchanges and order types.

        Parameters
        ----------
        price_type : str
            The type of the order, such as 'MARKET', 'STOP', or 'STOP_LIMIT'. For detailed information on possible values, see :ref:`variable_documentation`.
        time_in_force : str
            The duration for which the order remains active, like 'IOC', 'FOK', 'GTC', 'GTD'. For detailed information on possible values, see :ref:`variable_documentation`.
        exchange : str
            The exchange where the order is being placed, e.g., 'ICE', 'CME', 'EUREX'. For detailed information on possible values, see :ref:`variable_documentation`.
        price : float or None, optional
            The price at which the order is placed. Required for certain order types.
        stop_price : float or None, optional
            The stop price for the order. Required for 'STOP' and 'STOP_LIMIT' orders.

        Raises
        ------
        ValueError
            If the exchange is not supported or if the combination of parameters is invalid for the specified order type.
        AssertionError
            If the conditions for a valid order placement based on the exchange, price type, and time in force are not met.

        Notes
        -----
        - The method uses assertions to validate the parameter combinations, which will raise an AssertionError if any condition fails.
        """
        
        ## Exchange Order type checks
        if exchange == "ICE":
            if price_type == "MARKET":
                assert time_in_force not in ["IOC", "FOK", "GTC", "GTD"]

            elif price_type == "STOP_LIMIT":
                assert time_in_force not in ['IOC', 'FOK']
            
            elif price_type == "STOP":
                assert time_in_force not in ['IOC', 'FOK', "GTD"]
            
        elif exchange == "CME":
            if price_type == "MARKET":
                assert time_in_force not in ['GTC', 'GTD']

            elif price_type == 'STOP':
                assert time_in_force not in ['IOC', 'FOK']
            
            elif price_type == 'STOP_LIMIT':
                assert time_in_force not in ['IOC', 'FOK']
                
        #
        elif exchange == 'EUREX':
            if price_type == "MARKET":
                assert time_in_force not in ['IOC']
            
            elif price_type == "STOP_LIMIT":
                assert time_in_force not in ['IOC', 'GTC', 'GTD', 'ATC']
            
            elif price_type == "STOP":
                assert time_in_force not in ['IOC', 'ATC']
        
        elif exchange == 'EURONEXT':
            if price_type == "MARKET":
                assert time_in_force in ["IOC", "FOK"]
            
            elif price_type == "LIMIT":
                assert time_in_force in ["IOC", "FOK", "GTC", "GTD", "DAY"]
        
        
        elif exchange == 'ICE_L':
            if price_type == "MARKET":
                assert time_in_force not in ['GTC', 'GTD', "IOC"]
            
            elif price_type == "STOP_LIMIT":
                assert time_in_force not in ['IOC', 'FOK']
            
            elif price_type == "STOP":
                assert time_in_force not in ['IOC', 'FOK', "GTD"]
                
        elif exchange == 'JPX':
            if price_type == "MARKET":
                assert time_in_force in ["IOC", "FOK"]
            
        elif exchange == 'HKEX':
            pass
        
        else:
            raise ValueError("Exchange not supported")
        
        
        ## Price checks
        if price_type in ["STOP_LIMIT"]:
            assert (price is not None) and (stop_price is not None), "price and stop_price must be specified for 'STOP_LIMIT' orders"
        
        elif price_type in ["STOP"]:
            assert (stop_price is not None) and (price is None), "stop_price must be specified and price must be `None` for 'STOP' orders"

        elif price_type in ["MARKET"]:
            assert (price is None) and (stop_price is None), "price and stop_price must be `None` for 'MARKET' orders"        
        
        elif price_type not in ["STOP", "STOP_LIMIT", "MARKET"]:
            assert (price is not None) and (stop_price is None), f"price must be specified and stop_price must be `None` for {price_type} orders"
        
        
    
    def place_order(self, symbol, side, size, price_type, time_in_force, req_id, price=None, stop_price=None, auto_cancel=True, is_manual=False):
        
        """
        Sends a new order to the trading server.

        Places an order with the specified details by sending a request to the trading server. 
        Performs initial checks on the order parameters before sending the request.
        
        Parameters
        ----------
        symbol : str | int
            Unique identifier of the trading symbol.
        side : str
            The side of the order ('BUY' or 'SELL').
        size : int
            Order size.
        price_type : str
            Type of the order price. For detailed information on possible values, see :ref:`variable_documentation`.
        time_in_force : str
            Time-in-force policy of the order. For detailed information on possible values, see :ref:`variable_documentation`.
        req_id : int
            Unique identifier of the order provided by the client. This identifier is used to track the request in the `Pre-Acknowledged` state.
        price : float | None            
            Order price.
        stop_price : float | None            
            Stop Order price.
        auto_cancel : bool
            Flag indicating if the order should be automatically cancelled if client is disconnected from the trading server or python crashes/errors out.
        is_manual : bool
            Flag indicating if the order is manually placed using python code.

        Raises
        ------
        AssertionError
            If any of the parameters do not conform to the expected type or set of values.
        ValueError
            If the symbol is not in the trading universe or if the strategy state is not started.
        
        Returns
        -------
        order_id : int
            Identifier of the order that was sent. Use this identifier to get `UUID`.  
        """
        
        symbol_id = self.SYMBOL_ID_MAPPING.get(symbol, None)
        exchange = self.SYMBOL_EXCHANGE_MAPPING.get(symbol, None)
        region = self.ts_config.ts_exchange_region_mapping[exchange]
        
        ##
        account_id = self.ts_config.account_id_config[exchange]
        
        self.ts_config.masterlog.debug(f"Sending order to trading server, symbol: {symbol}, symbolID: {symbol_id}, side: {side}, price: {price}, size: {size}, price_type: {price_type}, time_in_force: {time_in_force}")

        assert side in ['BUY', 'SELL'], "side must be 'BUY' or 'SELL'"
        assert price_type in ['LIMIT', 'MARKET', 'STOP', 'STOP_LIMIT', 'MOC', 'LOC', 'MIT'], "price_type must be 'LIMIT', 'MARKET', 'STOP', 'STOP_LIMIT', 'MOC', 'LOC', or 'MIT'"
        assert time_in_force in ['IOC', 'FOK', 'DAY', 'GTD', 'GTC', 'OPG'], "time_in_force must be 'IOC', 'FOK', 'DAY', 'GTD', 'GTC', or 'OPG'"
        assert isinstance(symbol_id, int), "symbol_id must be an integer"
        assert isinstance(is_manual, bool), "is_manual must be a boolean"
        assert isinstance(req_id, int), "req_id must be an integer"
        assert isinstance(size, int), "size should be an integer, : {}".format(size)
        assert size > 0, "size must be greater than 0"
        if stop_price:
            assert isinstance(stop_price, float), "stop_price must be a float"

        if price:
            assert isinstance(price, float), "price must be a float"
        
        ##
        self.__place_order_checks(price_type=price_type, time_in_force=time_in_force, exchange=exchange, price=price, stop_price=stop_price)
        
        if self.get_state_symbol(symbol) != 'START': # returns 1 if symbol is in trading universe and strategy state is started
            raise ValueError("SymbolId NOT `started` or is NOT in `trading universe`")
        
        builder = flatbuffers.Builder(2048)
        
        tradeServer.NewOrderStart(builder)
        tradeServer.NewOrderAddSide(builder, getattr(tradeServer.Side, side))
        tradeServer.NewOrderAddSymbolId(builder, symbol_id)
        tradeServer.NewOrderAddClientId(builder, self.ts_config.client_id)
        tradeServer.NewOrderAddStrategyId(builder, self.ts_config.strategy_id)
        tradeServer.NewOrderAddAccountId(builder, account_id)
        tradeServer.NewOrderAddSize(builder, float(size))
        tradeServer.NewOrderAddPriceType(builder, getattr(tradeServer.PriceType, price_type))
        tradeServer.NewOrderAddTimeInForce(builder, getattr(tradeServer.TimeInForce, time_in_force))
        tradeServer.NewOrderAddClientReqId(builder, req_id)
        tradeServer.NewOrderAddIsManual(builder, is_manual)
        tradeServer.NewOrderAddAutoCancel(builder, auto_cancel)
        if price:
            tradeServer.NewOrderAddPrice(builder, price)

        if stop_price:
            tradeServer.NewOrderAddStopPrice(builder, stop_price)
        
        ##
        newOrder = tradeServer.NewOrderEnd(builder)

        ##
        tradeServer.TradeRequestMessageStart(builder)
        tradeServer.TradeRequestMessageAddTradeRequestUnionType(builder, tradeServer.TradeRequestUnion.newOrder)
        tradeServer.TradeRequestMessageAddTradeRequestUnion(builder, newOrder)
        tradeMsg = tradeServer.TradeServerRequestMessageEnd(builder)

        tradeServer.TradeServerRequestMessageStart(builder)
        tradeServer.AddMessageRequestUnionType(builder, tradeServer.MessageRequestUnion.tradeRequestMessage)
        tradeServer.AddMessageRequestUnion(builder, tradeMsg)
        requestMsg = tradeServer.TradeServerRequestMessageEnd(builder)
        builder.Finish(requestMsg)
        buf = builder.Output()

        self.ts_config.masterlog.debug("Sending order to trading server")
        
        socket = self.TS_DEALER_DICT[region]
        self.SEND_QUEUE.put((socket, buf))

        ##
        return req_id


    def query_order(self, req_id, uuid, exchange, is_manual=False):
        """
        Sends a request to the trading server to query the status of a specific order.

        Parameters
        ----------
        req_id:
            Unique identifier of the request. This identifier is used to get `uuid` of the request in `on_pre_acknowledge` callback.
        uuid : int
            Unique identifier of the order.
        exchange : str
            The exchange where the order was placed. For detailed information on possible values, see :ref:`variable_documentation`.
        is_manual : bool
            Flag indicating if the order is manually placed using python code.

        Raises
        ------
        AssertionError
            If order_id is not an integer or is_manual is not a boolean.
        """

        assert isinstance(is_manual, bool), "is_manual must be a boolean"
        assert isinstance(uuid, int), "order_id must be an integer"
        self.__exchange_check(exchange)
        region = self.ts_config.ts_exchange_region_mapping[exchange]
        account_id = self.ts_config.account_id_config[exchange]
        
        builder = flatbuffers.Builder(2048)
        
        tradeServer.QueryOrderStart(builder)
        tradeServer.QueryOrderAddStrategyId(builder, self.ts_config.strategy_id)
        tradeServer.QueryOrderAddClientId(builder, self.ts_config.client_id)
        tradeServer.QueryOrderAddUuId(builder, uuid)
        tradeServer.QueryOrderAddClientReqId(builder, req_id)
        tradeServer.QueryOrderAddAccountId(builder, account_id)
        tradeServer.QueryOrderAddIsManual(builder, is_manual)
        OrderStatus = tradeServer.QueryOrderEnd(builder)

        tradeServer.TradeRequestMessageStart(builder)
        tradeServer.TradeRequestMessageAddTradeRequestUnionType(builder, tradeServer.TradeRequestUnion.queryOrder)
        tradeServer.TradeRequestMessageAddTradeRequestUnion(builder, OrderStatus)
        tradeMsg = tradeServer.TradeServerRequestMessageEnd(builder)

        tradeServer.TradeServerRequestMessageStart(builder)
        tradeServer.AddMessageRequestUnionType(builder, tradeServer.MessageRequestUnion.tradeRequestMessage)
        tradeServer.AddMessageRequestUnion(builder, tradeMsg)
        requestMsg = tradeServer.TradeServerRequestMessageEnd(builder)
        builder.Finish(requestMsg)
        buf = builder.Output()

        socket = self.TS_DEALER_DICT[region]
        self.SEND_QUEUE.put((socket, buf))
 
        
    def cancel_order(self, req_id, uuid, exchange, is_manual=False):
        """
        Sends a request to the trading server to cancel a specific order.
        Perform initial checks on the order parameters before sending the request.

        Parameters
        ----------
        req_id: int
            Unique identifier of the request. This identifier is used to get `uuid` of the request in `on_pre_acknowledge` callback.
        uuid: int
            Unique identifier of the order to be cancelled.
        exchange : str
            The exchange where the order was placed. For detailed information on possible values, see :ref:`variable_documentation`.
        is_manual : bool
            Flag indicating if the order is manually placed using python code.

        Raises
        ------
        AssertionError
            If order_id is not an integer or is_manual is not a boolean.
        
        """

        assert isinstance(is_manual, bool), "is_manual must be a boolean"
        assert isinstance(uuid, int), "order_id must be an integer"
        self.__exchange_check(exchange)
        region = self.ts_config.ts_exchange_region_mapping[exchange]
        account_id = self.ts_config.account_id_config[exchange]
        
        self.ts_config.masterlog.debug("Sending Cancelling order Request: {}".format(uuid))

        builder = flatbuffers.Builder(2048)
        
        tradeServer.CancelOrderStart(builder)
        tradeServer.CancelOrderAddUuId(builder, uuid)
        tradeServer.CancelOrderAddClientReqId(builder, req_id)
        tradeServer.CancelOrderAddClientId(builder, self.ts_config.client_id)
        tradeServer.CancelOrderAddAccountId(builder, account_id)
        tradeServer.CancelOrderAddStrategyId(builder, self.ts_config.strategy_id)
        tradeServer.CancelOrderAddIsManual(builder, is_manual)
        newOrder = tradeServer.CancelOrderEnd(builder)

        tradeServer.TradeRequestMessageStart(builder)
        tradeServer.AddTradeRequestUnionType(builder, tradeServer.TradeRequestUnion.cancelOrder)
        tradeServer.AddTradeRequestUnion(builder, newOrder)
        tradeMsg = tradeServer.TradeServerRequestMessageEnd(builder)

        tradeServer.TradeServerRequestMessageStart(builder)
        tradeServer.AddMessageRequestUnionType(builder, tradeServer.MessageRequestUnion.tradeRequestMessage)
        tradeServer.AddMessageRequestUnion(builder, tradeMsg)
        requestMsg = tradeServer.TradeServerRequestMessageEnd(builder)
        builder.Finish(requestMsg)
        buf = builder.Output()

        socket = self.TS_DEALER_DICT[region]
        self.SEND_QUEUE.put((socket, buf))


    def modify_order(self, uuid, side, price, size, time_in_force, is_manual=False):
        """
        Sends a request to replace an existing order with new details.

        Parameters
        ----------
        msg_id : int
            Unique identifier of this message.
        order_id : int
            Identifier of the order to be replaced.
        side : str
            New order side, must be 'BUY' or 'SELL'.
        price : float
            New order price.
        size : int
            New order size.
        time_in_force : str
            New time-in-force policy of the order, e.g., 'IOC', 'FOK', 'DAY', 'GTD', 'GTC', 'OPG'
        is_manual : bool
            Flag indicating if the order is manually placed using python code.

        Raises
        ------
        AssertionError
            If parameters do not conform to the expected types or values.
            
        """
        raise NotImplementedError("Modify Order is not implemented yet")
    
        assert side in ['BUY', 'SELL'], "side must be 'BUY' or 'SELL'"
        assert isinstance(is_manual, bool), "is_manual must be a boolean"
        assert isinstance(uuid, int), "uuid must be an integer"
        assert isinstance(price, float), "price must be a float"
        assert time_in_force in ['IOC', 'FOK', 'DAY', 'GTD', 'GTC', 'OPG'], "time_in_force must be 'IOC', 'FOK', or 'DAY'"

        assert isinstance(size, int), "size should be an integer, : {}".format(size)

        self.ts_config.masterlog.debug(f"Replacing order {uuid}: side: {side}, price: {price}, size: {size}")

        builder = flatbuffers.Builder(2048)

        tradeServer.ReplaceOrderStart(builder)
        tradeServer.ReplaceOrderAddSide(builder, getattr(tradeServer.Side, side))
        tradeServer.ReplaceOrderAddPrice(builder, price)
        tradeServer.ReplaceOrderAddSize(builder, float(size))
        tradeServer.ReplaceOrderAddUuId(builder, uuid)
        tradeServer.ReplaceOrderAddStrategyId(builder, self.ts_config.strategy_id)
        tradeServer.ReplaceOrderAddClientId(builder, self.ts_config.client_id)
        tradeServer.ReplaceOrderAddtime_in_force(builder, getattr(tradeServer.time_in_force, time_in_force))
        tradeServer.ReplaceOrderAddIsManual(builder, is_manual)
        newOrder = tradeServer.ReplaceOrderEnd(builder)

        tradeServer.TradeRequestMessageStart(builder)
        tradeServer.TradeRequestMessageAddTradeRequestUnionType(builder, tradeServer.TradeRequestUnion.replaceOrder)
        tradeServer.TradeRequestMessageAddTradeRequestUnion(builder, newOrder)
        tradeMsg = tradeServer.TradeServerRequestMessageEnd(builder)

        tradeServer.TradeServerRequestMessageStart(builder)
        tradeServer.AddMessageRequestUnionType(builder, tradeServer.MessageRequestUnion.tradeRequestMessage)
        tradeServer.AddMessageRequestUnion(builder, tradeMsg)
        requestMsg = tradeServer.TradeServerRequestMessageEnd(builder)
        builder.Finish(requestMsg)
        buf = builder.Output()



    def query_position_clientid(self, symbol):
        """
        Sends a request to the trading server for position details of a specific symbol associated with the client id.

        Parameters
        ----------
        symbol : int | str
            Unique identifier of the trading symbol to query. It must be in trading universe.

        Raises
        ------
        AssertionError
            If symbol_id is not an integer.
         
        """
        
        symbol_id = self.SYMBOL_ID_MAPPING.get(symbol, None)
        exchange = self.SYMBOL_EXCHANGE_MAPPING.get(symbol, None)
        region = self.ts_config.ts_exchange_region_mapping[exchange]
        account_id = self.ts_config.account_id_config[exchange]
        
        assert isinstance(symbol_id, int), "symbol not in trading universe"
        
        ##
        builder = flatbuffers.Builder(2048)
        tradeServer.QueryPositionClientIdRequestMessageStart(builder)
        tradeServer.QueryPositionClientIdRequestMessageAddStrategyId(builder, self.ts_config.strategy_id)
        tradeServer.QueryPositionClientIdRequestMessageAddClientId(builder, self.ts_config.client_id)
        tradeServer.QueryPositionClientIdRequestMessageAddSymbolId(builder, symbol_id)
        query_position_request_message = tradeServer.QueryPositionClientIdRequestMessageEnd(builder)
        
        tradeServer.AdminRequestMessageStart(builder)
        tradeServer.AdminRequestMessageAddAdminRequestUnionType(builder, tradeServer.AdminRequestUnion.queryPositionClientIdRequestMessage)
        tradeServer.AdminRequestMessageAddAdminRequestUnion(builder, query_position_request_message)
        admin_request_message = tradeServer.AdminRequestMessageEnd(builder)
        
        tradeServer.TradeServerRequestMessageStart(builder)
        tradeServer.TradeServerRequestMessageAddMessageRequestUnionType(builder, tradeServer.MessageRequestUnion.adminRequestMessage)
        tradeServer.TradeServerRequestMessageAddMessageRequestUnion(builder, admin_request_message)
        trade_server_request_message = tradeServer.TradeServerRequestMessageEnd(builder)
        
        builder.Finish(trade_server_request_message)
        buf = builder.Output()
        
        socket = self.TS_DEALER_DICT[region]
        self.SEND_QUEUE.put((socket, buf))
    
    
    def query_position_accountid(self, symbol):
        """
        Sends a request to the trading server for position details of a specific symbol associated with the account id.

        Parameters
        ----------
        symbol : int | str
            Unique identifier of the trading symbol to query. It must be in trading universe.

        Raises
        ------
        AssertionError
            If symbol_id is not an integer.
         
        """
        
        symbol_id = self.SYMBOL_ID_MAPPING.get(symbol, None)
        exchange = self.SYMBOL_EXCHANGE_MAPPING.get(symbol, None)
        region = self.ts_config.ts_exchange_region_mapping[exchange]
        account_id = self.ts_config.account_id_config[exchange]

        assert isinstance(symbol_id, int), "symbol not in trading universe"
        
        ##
        builder = flatbuffers.Builder(2048)
        tradeServer.QueryPositionAccountIdRequestMessageStart(builder)
        tradeServer.QueryPositionAccountIdRequestMessageAddStrategyId(builder, self.ts_config.strategy_id)
        tradeServer.QueryPositionAccountIdRequestMessageAddAccountId(builder, account_id)
        tradeServer.QueryPositionAccountIdRequestMessageAddSymbolId(builder, symbol_id)
        query_position_request_message = tradeServer.QueryPositionAccountIdRequestMessageEnd(builder)
        
        tradeServer.AdminRequestMessageStart(builder)
        tradeServer.AdminRequestMessageAddAdminRequestUnionType(builder, tradeServer.AdminRequestUnion.queryPositionAccountIdRequestMessage)
        tradeServer.AdminRequestMessageAddAdminRequestUnion(builder, query_position_request_message)
        admin_request_message = tradeServer.AdminRequestMessageEnd(builder)
        
        tradeServer.TradeServerRequestMessageStart(builder)
        tradeServer.TradeServerRequestMessageAddMessageRequestUnionType(builder, tradeServer.MessageRequestUnion.adminRequestMessage)
        tradeServer.TradeServerRequestMessageAddMessageRequestUnion(builder, admin_request_message)
        trade_server_request_message = tradeServer.TradeServerRequestMessageEnd(builder)
        
        builder.Finish(trade_server_request_message)
        buf = builder.Output()
        
        socket = self.TS_DEALER_DICT[region]
        self.SEND_QUEUE.put((socket, buf))

    
    def cancel_all_orders(self, req_id, exchange, is_manual=False):
        """
        Sends a request to the trading server to cancel all active orders for a specific exchange.
        
        Parameters
        ----------
        req_id : int
            Unique identifier of the request. This identifier is used to get `uuid` of the request in `on_pre_acknowledge` callback.
        exchange : str
            The exchange for which to retrieve active orders. For detailed information on possible values, see :ref:`variable_documentation`.
        is_manual : bool
            Flag indicating if the order is manually placed using python code.
        """
        
        self.__exchange_check(exchange)
        region = self.ts_config.ts_exchange_region_mapping[exchange]
        account_id = self.ts_config.account_id_config[exchange]
        
        builder = flatbuffers.Builder(2048)
        
        ##
        tradeServer.CancelAllOrdersStart(builder)
        tradeServer.CancelAllOrdersAddClientReqId(builder, req_id)
        tradeServer.CancelAllOrdersAddClientId(builder, self.ts_config.client_id)
        tradeServer.CancelAllOrdersAddStrategyId(builder, self.ts_config.strategy_id)
        tradeServer.CancelAllOrdersAddAccountId(builder, account_id)
        tradeServer.CancelAllOrdersAddIsManual(builder, is_manual)
        cancel_all_orders = tradeServer.CancelAllOrdersEnd(builder)

        tradeServer.TradeRequestMessageStart(builder)
        tradeServer.AddTradeRequestUnionType(builder, tradeServer.TradeRequestUnion.cancelAllOrders)
        tradeServer.AddTradeRequestUnion(builder, cancel_all_orders)
        tradeMsg = tradeServer.TradeServerRequestMessageEnd(builder)

        tradeServer.TradeServerRequestMessageStart(builder)
        tradeServer.AddMessageRequestUnionType(builder, tradeServer.MessageRequestUnion.tradeRequestMessage)
        tradeServer.AddMessageRequestUnion(builder, tradeMsg)
        requestMsg = tradeServer.TradeServerRequestMessageEnd(builder)
        builder.Finish(requestMsg)
        buf = builder.Output()

        socket = self.TS_DEALER_DICT[region]
        self.SEND_QUEUE.put((socket, buf))


    def query_all_active_orders(self, req_id, exchange, isManual=False):
        """
        Sends a request to the trading server to retrieve details of all active orders for a specific exchange.
        
        Parameters
        ----------
        req_id : int
            Unique identifier of the request. This identifier is used to get `uuid` of the request in `on_pre_acknowledge` callback.
        exchange : str
            The exchange for which to retrieve active orders. For detailed information on possible values, see :ref:`variable_documentation`.
        isManual : bool, optional
            Indicates whether the request is manual. Default is False.
        """
        
        self.__exchange_check(exchange)
        region = self.ts_config.ts_exchange_region_mapping[exchange]
        account_id = self.ts_config.account_id_config[exchange]

        builder = flatbuffers.Builder(2048)
        
        ##
        tradeServer.QueryAllOrdersStart(builder)
        tradeServer.QueryAllOrdersAddClientId(builder, self.ts_config.client_id)
        tradeServer.QueryAllOrdersAddClientReqId(builder, req_id)
        tradeServer.QueryAllOrdersAddStrategyId(builder, self.ts_config.strategy_id)
        tradeServer.QueryAllOrdersAddAccountId(builder, account_id)
        tradeServer.QueryAllOrdersAddIsManual(builder, isManual)
        query_all_orders = tradeServer.QueryAllOrdersEnd(builder)
        
        tradeServer.TradeRequestMessageStart(builder)
        tradeServer.AddTradeRequestUnionType(builder, tradeServer.TradeRequestUnion.queryAllOrders)
        tradeServer.AddTradeRequestUnion(builder, query_all_orders)
        tradeMsg = tradeServer.TradeServerRequestMessageEnd(builder)

        tradeServer.TradeServerRequestMessageStart(builder)
        tradeServer.AddMessageRequestUnionType(builder, tradeServer.MessageRequestUnion.tradeRequestMessage)
        tradeServer.AddMessageRequestUnion(builder, tradeMsg)
        requestMsg = tradeServer.TradeServerRequestMessageEnd(builder)
        builder.Finish(requestMsg)
        buf = builder.Output()

        socket = self.TS_DEALER_DICT[region]
        self.SEND_QUEUE.put((socket, buf))
        
        
        