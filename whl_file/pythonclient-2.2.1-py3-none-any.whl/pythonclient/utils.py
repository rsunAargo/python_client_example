
import signal
from contextlib import contextmanager
import zmq
from zmq.utils.monitor import parse_monitor_message
import functools
from pythonclient.config_read import ConfigObjectClass
import functools
from sortedcontainers import SortedDict


def raise_timeout(signum, frame):
    print("timeout")
    raise Exception("timouttt")

@contextmanager
def timeout(time):
    # Register a function to raise a TimeoutError on the signal.
    signal.signal(signal.SIGALRM, raise_timeout)
    # Schedule the signal to be sent after ``time``.
    signal.alarm(time)
    try:
        
        yield
    except TimeoutError:
        a =1
        #exit()
        #pass
    finally:
        signal.signal(signal.SIGALRM, signal.SIG_IGN)


@functools.lru_cache(maxsize=2)
def get_events_dict():
    event_key_dict = {value: key for key, value in zmq.__dict__.items() if key.startswith('EVENT_')}
    return event_key_dict
    

##
def event_monitoring(monitor_socket, config: ConfigObjectClass):
        
    try:        
        msg = monitor_socket.recv_multipart()
        event = parse_monitor_message(msg)

        event_dict = get_events_dict()
        event_name = event_dict.get(event['event'], "UNKNOWN")
        config.socker_monitor_logger.info(f"{event_name}. Value is: {event['value']}, Address is: {event['endpoint']}")

    except Exception as e:
        import traceback
        config.socker_monitor_logger.critical(f"Exception in event_monitoring: {traceback.format_exc()}")        
        config.socker_monitor_logger.critical(f"Exception in event_monitoring: {e}")

#    
def get_symbol_map_dict(trading_universe, symbol_source, cursor):
    
    ##
    if symbol_source == "SYMBOL_ID":
        assert all([isinstance(x, int) for x in trading_universe]), "All symbols should be integer"  
    #
    trading_universe_tup = tuple(trading_universe)
    if len(trading_universe_tup) == 1:
        trading_universe_tup = trading_universe_tup + trading_universe_tup
    
    #
    col_name = str(symbol_source).lower()
    query_ = f"SELECT symbol_id, exchange, {col_name} from aargo_security_master_final where {col_name} in {trading_universe_tup}"
    cursor.execute(query_)
    
    data = cursor.fetchall()
    
    if len(data) != len(trading_universe):
        missing_symbols = set(trading_universe) - set([x[col_name] for x in data])
        raise Exception(f"Following symbols are missing in the database: {missing_symbols}")

    ##
    symbol_id_map = {x[col_name]:int(x['symbol_id']) for x in data} 
    symbol_exchange_map = {x[col_name]:x['exchange'] for x in data}
    
    return symbol_id_map, symbol_exchange_map    

