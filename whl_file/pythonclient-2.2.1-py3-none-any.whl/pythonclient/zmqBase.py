
import zmq

class ZMQBase:
    
    def __init__(self):
        self.ZMQ_CONTEXT = zmq.Context()
        self.TS_DEALER_DICT = dict()
        self.MD_DEALER_DICT = dict()
        self.MD_SUB_DICT = dict()
        self.SOCKET_INFO_DICT = dict()
        self.ALL_SOCKET_LIST = list()
        self.ZMQ_CALLBACK_DICT = dict()
        
        